# main.py
import os
import streamlit as st
from dotenv import load_dotenv
from runners.brd_runner import BRDRunner
from agents.requirement_collector import RequirementCollectorAgent
from core.session import BRDSession

load_dotenv()
API_KEY = os.getenv("GOOGLE_API_KEY")

st.set_page_config(page_title="BRD Generator", layout="centered")

if "session" not in st.session_state:
    st.session_state.session = BRDSession()
    st.session_state.collector = RequirementCollectorAgent(API_KEY)
    st.session_state.current_question = st.session_state.collector.start_conversation()
    st.session_state.finished = False
    st.session_state.brd_result = None

st.title("📄 ScopeWise: BRD Generator")

if not st.session_state.finished:
    st.markdown("### " + st.session_state.current_question)
    user_input = st.text_input("Your Answer:", key="user_input")

    if st.button("Submit Answer"):
        if user_input:
            st.session_state.session.add_entry(st.session_state.current_question, user_input)
            next_q = st.session_state.collector.get_follow_up(st.session_state.session.get_history())

            if next_q:
                st.session_state.current_question = next_q
                st.rerun()
            else:
                st.session_state.finished = True
                st.success("Requirement collection completed. Generating BRD...")

                runner = BRDRunner(API_KEY)
                st.session_state.brd_result = runner.run(st.session_state.session.get_history())
                st.rerun()
else:
    result = st.session_state.brd_result

    if "error" in result:
        st.error("Issues found: " + "; ".join(result["error"]))
    else:
        st.markdown("### 📝 Final BRD Document")
        st.text_area("Final Text", result["final"], height=400)

        st.download_button("⬇️ Download .docx", open(result["docx_path"], "rb"), file_name="BRD.docx")
        #st.download_button("⬇️ Download .pdf", open(result["pdf_path"], "rb"), file_name="BRD.pdf")

    if st.button("🔁 Start Over"):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()
