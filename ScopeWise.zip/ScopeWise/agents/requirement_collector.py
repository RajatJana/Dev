import google.generativeai as genai

class RequirementCollectorAgent:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name="gemini-1.5-flash")
        self.questions = []
        self.generated = False

    def _generate_questions(self):
        prompt = (
            "You are a business analyst assistant. Generate a list of 8 structured, "
            "clear questions to collect requirements for creating a Business Requirements Document (BRD). "
            "The questions should be ordered logically and cover business goals, stakeholders, features, constraints, etc. "
            "Return only the list of questions."
        )
        response = self.model.generate_content(prompt)
        raw = response.text
        self.questions = [line.strip("- ").strip() for line in raw.strip().split("\n") if line.strip()]
        self.generated = True

    def start_conversation(self):
        if not self.generated:
            self._generate_questions()
        return self.questions[0]

    def get_follow_up(self, previous_qas):
        if not self.generated:
            self._generate_questions()
        if len(previous_qas) < len(self.questions):
            return self.questions[len(previous_qas)]
        return None
