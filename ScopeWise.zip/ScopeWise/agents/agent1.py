import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

class QuestionGenerator:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY_1")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        
    def generate_questions(self, project_description, industry):
        with open("prompts/agent1_initial_prompt.txt", "r") as f:
            prompt_template = f.read()
        
        prompt = prompt_template.format(
            project_description=project_description,
            industry=industry
        )
        
        response = self.model.generate_content(prompt)
        return self._parse_questions(response.text)
    
    def _parse_questions(self, text):
        """Parse the generated text into individual questions"""
        questions = []
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                # Remove numbering/bullets and extra spaces
                question = line.split('.', 1)[-1].strip() if '.' in line else line[1:].strip()
                questions.append(question)
        return questions