# agents/formatter_agent.py
import google.generativeai as genai

class FormatterAgent:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name="gemini-2.0-flash")

    def generate_draft(self, qas):
        prompt = """You are a technical writer assistant. Use the following Q&A responses to create a structured Business Requirement Document (BRD) with these sections:

1. Project Name
2. Project Goals
3. Stakeholders
4. Target Audience
5. Functional Requirements
6. Constraints
7. Timeline

Format it clearly with section headers.

Responses:
"""
        for qa in qas:
            prompt += f"\nQ: {qa['question']}\nA: {qa['answer']}\n"

        response = self.model.generate_content(prompt)
        return response.text
