# agents/export_agent.py
from docx import Document
from fpdf import FPDF
import os

class ExportAgent:
    def to_docx(self, content, filename="BRD_Document.docx"):
        doc = Document()
        doc.add_heading("Business Requirements Document", 0)
        for line in content.split('\n'):
            if line.strip():
                if line.strip().endswith(":"):
                    doc.add_heading(line.strip(), level=1)
                else:
                    doc.add_paragraph(line.strip())
        doc.save(filename)
        return filename

    # def to_pdf(self, content, filename="BRD_Document.pdf"):
    #     pdf = FPDF()
    #     pdf.add_page()
    #     pdf.set_font("Arial", size=12)
    #     for line in content.split('\n'):
    #         pdf.multi_cell(0, 10, line)
    #     pdf.output(filename)
    #     return filename
