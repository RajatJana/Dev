# agents/clarity_validator.py
import google.generativeai as genai

class ClarityValidatorAgent:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name="gemini-2.0-flash")

    def validate(self, qas):
        prompt = """You are a clarity-checking assistant. Identify which responses are vague, generic, or incomplete. 
        Suggest what clarification is needed, if any.

        Responses:
        """
        for qa in qas:
            prompt += f"\nQ: {qa['question']}\nA: {qa['answer']}\n"

        prompt += "\nPlease return a list of feedback for each vague or unclear response."

        response = self.model.generate_content(prompt)
        return response.text
