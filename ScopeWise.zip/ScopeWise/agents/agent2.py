import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

class AutoResponder:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY_2")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        
    def generate_response(self, question, project_description, industry):
        with open("prompts/agent2_response_prompt.txt", "r") as f:
            prompt_template = f.read()
        
        prompt = prompt_template.format(
            question=question,
            project_description=project_description,
            industry=industry
        )
        
        response = self.model.generate_content(prompt)
        return response.text