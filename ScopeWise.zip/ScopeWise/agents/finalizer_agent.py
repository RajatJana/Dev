# agents/finalizer_agent.py
import google.generativeai as genai

class FinalizerAgent:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name="gemini-2.0-flash")

    def polish_document(self, draft_text):
        prompt = f"""You are a professional document editor. Refine the following BRD for clarity, grammar, tone, and structure:

---
{draft_text}
---

Return a final polished version."""
        response = self.model.generate_content(prompt)
        return response.text
