import streamlit as st
from agents.agent1 import QuestionGenerator
from agents.agent2 import AutoResponder

# Initialize agents
question_generator = QuestionGenerator()
auto_responder = AutoResponder()

# Configure page settings
st.set_page_config(
    page_title="ScopeWise: AI-Driven BRD Generator",
    page_icon="📝",
    layout="centered"
)

# Custom CSS for better styling
def load_css():
    st.markdown("""
    <style>
        .stTextArea textarea {
            min-height: 150px;
        }
        .stProgress > div > div > div {
            background-color: #4CAF50;
        }
        .question-card {
            padding: 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .summary-card {
            padding: 1rem;
            border-radius: 0.5rem;
            border-left: 4px solid #4CAF50;
            background-color: #f8f9fa;
            margin-bottom: 1rem;
        }
        .button-row button {
            width: 100%;
            margin: 0.25rem 0;
        }
    </style>
    """, unsafe_allow_html=True)

load_css()

# Welcome page
def show_welcome():
    st.title("ScopeWise: AI-Driven BRD Generator")
    #st.image("https://via.placeholder.com/800x200?text=ScopeWise+BRD+Generator", use_column_width=True)
    
    st.write("""
    ### Welcome to ScopeWise!
    This AI-powered tool will guide you through creating a comprehensive Business Requirements Document (BRD) 
    by asking targeted questions about your project.
    """)
    
    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        if st.button("🚀 Start BRD Creation", use_container_width=True):
            st.session_state.current_page = "project_info"
            st.rerun()

# Project information page
def show_project_info():
    st.title("1. Project Information")
    st.write("Let's start with some basic information about your project.")
    
    industries = [
        "Select industry...",
        "Technology/SaaS",
        "Healthcare",
        "Financial Services", 
        "Retail/E-commerce",
        "Education",
        "Manufacturing",
        "Government",
        "Non-profit",
        "Other"
    ]
    
    with st.form("project_info_form"):
        project_description = st.text_area(
            "Project Description*",
            placeholder="Briefly describe your project or product need...",
            help="Provide enough detail to generate relevant requirements questions"
        )
        
        industry = st.selectbox(
            "Industry*",
            industries,
            index=0,
            help="Select the primary industry for this project"
        )
        
        submitted = st.form_submit_button("Generate Questions →")
        
        if submitted:
            if not project_description.strip():
                st.error("Please provide a project description")
            elif industry == "Select industry...":
                st.error("Please select an industry")
            else:
                st.session_state.project_description = project_description
                st.session_state.industry = industry
                
                with st.spinner("🧠 Generating tailored questions for your BRD..."):
                    try:
                        questions = question_generator.generate_questions(
                            st.session_state.project_description,
                            st.session_state.industry
                        )
                        
                        if not questions:
                            st.error("Failed to generate questions. Please try again.")
                            return
                            
                        st.session_state.questions_answers = [
                            {"question": q, "answer": ""} for q in questions
                        ]
                        st.session_state.current_question_index = 0
                        st.session_state.current_page = "qa_session"
                        st.rerun()
                    except Exception as e:
                        st.error(f"An error occurred: {str(e)}")

# Q&A Session page
def show_qa_session():
    st.title("2. Requirements Gathering")
    
    total_questions = len(st.session_state.questions_answers)
    current_index = st.session_state.current_question_index
    current_qa = st.session_state.questions_answers[current_index]
    
    # Question selection dropdown
    question_options = [f"Question {i+1}" for i in range(total_questions)]
    selected_question = st.selectbox(
        "Jump to question:",
        question_options,
        index=current_index,
        key="question_selector"
    )
    
    # Update current index if dropdown changed
    if question_options.index(selected_question) != current_index:
        st.session_state.current_question_index = question_options.index(selected_question)
        st.rerun()
    
    # Progress indicator
    st.progress((current_index + 1) / total_questions)
    st.caption(f"Question {current_index + 1} of {total_questions}")
    
    # Current question card
    with st.container(border=True):
        st.markdown(f"### {current_qa['question']}")
    
    # Answer form
    with st.form("answer_form"):
        answer = st.text_area(
            "Your Answer",
            value=current_qa.get("answer", ""),
            placeholder="Type your answer here or use Auto-Generate...",
            key=f"answer_{current_index}"
        )
        
        # Button row
        col1, col2, col3 = st.columns(3)
        with col1:
            submit_btn = st.form_submit_button(
                "✅ Submit Answer" if answer.strip() else "⏭️ Skip Question",
                type="primary",
                use_container_width=True
            )
        with col2:
            auto_btn = st.form_submit_button(
                "🤖 Auto-Generate",
                use_container_width=True
            )
        with col3:
            if current_index < total_questions - 1:
                next_btn = st.form_submit_button(
                    "➡️ Next Question",
                    use_container_width=True
                )
            else:
                finish_btn = st.form_submit_button(
                    "🏁 Finish & Review",
                    type="secondary",
                    use_container_width=True
                )
        
        # Handle form submissions
        if auto_btn:
            with st.spinner("Generating suggested answer..."):
                current_qa["answer"] = auto_responder.generate_response(
                    current_qa["question"],
                    st.session_state.project_description,
                    st.session_state.industry
                )
            st.rerun()
            
        if submit_btn:
            current_qa["answer"] = answer if answer.strip() else "Skipped"
            move_to_next_question()
            
        if 'next_btn' in locals() and next_btn:
            move_to_next_question()
            
        if 'finish_btn' in locals() and finish_btn:
            st.session_state.current_page = "completion"
            st.rerun()

def move_to_next_question():
    if st.session_state.current_question_index < len(st.session_state.questions_answers) - 1:
        st.session_state.current_question_index += 1
    else:
        st.session_state.current_page = "completion"
    st.rerun()

# Completion page
def show_completion():
    st.title("3. BRD Questionnaire Complete")
    st.balloons()
    st.success("You've completed all questions for your Business Requirements Document!")
    
    # Project summary
    with st.container(border=True):
        st.markdown("### Project Summary")
        st.markdown(f"**Industry:** {st.session_state.industry}")
        st.markdown(f"**Description:** {st.session_state.project_description}")
    
    # Questions & Answers summary
    st.markdown("### Your BRD Questionnaire")
    for i, qa in enumerate(st.session_state.questions_answers):
        with st.container(border=True):
            st.markdown(f"#### Question {i + 1}")
            st.markdown(f"{qa['question']}")
            st.markdown(f"**Answer:** {qa['answer'] if qa['answer'] else 'Not answered'}")
    
    # Navigation buttons
    st.write("")  # Spacer
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("✏️ Edit Answers", use_container_width=True):
            st.session_state.current_page = "qa_session"
            st.rerun()
    with col2:
        if st.button("🔄 Start New BRD", use_container_width=True):
            st.session_state.clear()
            st.session_state.current_page = "welcome"
            st.rerun()
    with col3:
        if st.button("📄 Generate BRD", type="primary", use_container_width=True):
            st.session_state.current_page = "generate_brd"
            st.rerun()

# BRD Generation page (placeholder for next phase)
def show_generate_brd():
    st.title("4. Generate BRD Document")
    st.warning("This feature will be implemented in the next phase")
    st.write("Here we will compile all your answers into a professional BRD document.")
    
    if st.button("← Back to Summary"):
        st.session_state.current_page = "completion"
        st.rerun()

# Main app flow
def main():
    if "current_page" not in st.session_state:
        st.session_state.current_page = "welcome"
    
    pages = {
        "welcome": show_welcome,
        "project_info": show_project_info,
        "qa_session": show_qa_session,
        "completion": show_completion,
        "generate_brd": show_generate_brd
    }
    
    pages[st.session_state.current_page]()

if __name__ == "__main__":
    main()