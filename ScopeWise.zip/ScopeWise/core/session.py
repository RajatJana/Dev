# core/session.py
class BRDSession:
    def __init__(self):
        self.qa_memory = []

    def add_entry(self, question, answer):
        self.qa_memory.append({"question": question, "answer": answer})

    def get_history(self):
        return self.qa_memory

    def reset(self):
        self.qa_memory = []
