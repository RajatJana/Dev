def compile_brd(messages: list[dict]) -> str:
    """
    Extract user answers from chat and build a simple BRD.
    """
    user_answers = [msg["text"] for msg in messages if msg["role"] == "user"]

    sections = [
        ("Project Name", user_answers[0] if len(user_answers) > 0 else ""),
        ("Project Goals", user_answers[1] if len(user_answers) > 1 else ""),
        ("Stakeholders", user_answers[2] if len(user_answers) > 2 else ""),
        ("Target Users", user_answers[3] if len(user_answers) > 3 else ""),
        ("User Details", user_answers[4] if len(user_answers) > 4 else ""),
        ("Core Features", user_answers[5] if len(user_answers) > 5 else ""),
        ("Constraints", user_answers[6] if len(user_answers) > 6 else ""),
        ("Detailed Constraints", user_answers[7] if len(user_answers) > 7 else ""),
        ("Timeline", user_answers[8] if len(user_answers) > 8 else ""),
        ("Clarification", user_answers[9] if len(user_answers) > 9 else ""),
        ("Final Confirmation", user_answers[10] if len(user_answers) > 10 else "")
    ]

    brd_text = "# Business Requirements Document (BRD)\n\n"
    for title, content in sections:
        brd_text += f"## {title}\n{content}\n\n"

    return brd_text
