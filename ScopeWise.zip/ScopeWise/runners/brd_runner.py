# runners/brd_runner.py
from agents.requirement_collector import RequirementCollectorAgent
from agents.clarity_validator import ClarityValidatorAgent
from agents.formatter_agent import FormatterAgent
from agents.finalizer_agent import FinalizerAgent
from agents.export_agent import ExportAgent

class BRDRunner:
    def __init__(self, api_key):
        self.collector = RequirementCollectorAgent(api_key)
        self.validator = ClarityValidatorAgent(api_key)
        self.formatter = FormatterAgent(api_key)
        self.finalizer = FinalizerAgent(api_key)
        self.exporter = ExportAgent()

    def run(self, user_inputs: list):
        # Step 1: Validate Clarity
        # issues = self.validator.validate(user_inputs)
        # if issues:
        #     return {"error": issues}

        # Step 2: Format Draft
        draft = self.formatter.generate_draft(user_inputs)

        # Step 3: Finalize Document
        final_doc = self.finalizer.polish_document(draft)

        # Step 4: Export
        docx_file = self.exporter.to_docx(final_doc)

        return {
            "draft": draft,
            "final": final_doc,
            "docx_path": docx_file
        }
