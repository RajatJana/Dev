from agents.requirement_collector import get_agent_response

def run_chat(messages):
    """
    messages: list of dicts with role=user|model, text=...
    Returns updated message list with agent's reply appended.
    """
    # Convert to Gemini expected format
    formatted = [{"role": msg["role"], "parts": [{"text": msg["text"]}]} for msg in messages]
    
    # Get response from the agent
    response = get_agent_response(formatted)
    
    # Append and return
    messages.append({"role": "model", "text": response})
    return messages
