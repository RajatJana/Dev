import json
import faiss
import numpy as np
import torch
import os
import re
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from transformers import AutoTokenizer, AutoModel


def get_embeddings(text):
    tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    inputs = tokenizer(text, return_tensors='pt', padding=True, truncation=True)
    
    with torch.no_grad():
        embeddings = model(**inputs)
    return embeddings.last_hidden_state.mean(dim=1).squeeze().numpy()

def remove_prefix_suffix(file_content: str) -> str:
    """
    Removes lines starting with ''' json or ''' yaml,
    and standalone ''' lines from the given content.
    """
    pattern = r"^'''\s*(json|yaml)\s*$|^'''\s*$"
    cleaned_content = re.sub(pattern, "", file_content, flags=re.MULTILINE)
    return cleaned_content.strip()
def clean_llm_output(output: str) -> str:
    # Removes leading and trailing triple quotes with optional language tag
    return re.sub(r"^'''[a-zA-Z0-9]*\s*|\s*'''$", "", output.strip())


def load_model(model_name):
    #os.environ["GOOGLE_API_KEY"]="AIzaSyArYq9kel4SMUDYNpFhhuRq40YJQuICNwM"
    os.environ["GOOGLE_API_KEY"]="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ"
    llm = ChatGoogleGenerativeAI(
          model= model_name,
          temperature=0,
          max_tokens=None,
          timeout=None,
          max_retries=2
          # other params...
    )
    return llm

# Load JSON Data
def load_json(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)



def create_faiss_index( example_inputs):
    #Create and Populate Faiss Index
    example_embeddings = [get_embeddings(text) for text in example_inputs]
    dimension = example_embeddings[0].shape[0]
    index = faiss.IndexFlatL2(dimension)
    embedding_matrix = np.array(example_embeddings).reshape(-1,dimension)
    index.add(embedding_matrix)
    return index

# Function to find the most relevant example using FAISS
def find_relevant_examples(data,index,user_query, top_k=3):
    # Load pre-trained embedding model
    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    query_embedding = embedding_model.encode(user_query).reshape(1, -1)
    distances, indices = index.search(query_embedding, top_k)
    relevant_examples=[data[i] for i in indices[0]]
    return relevant_examples

