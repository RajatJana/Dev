from google.adk.agents import LlmAgent
from tools.generator_tool import generate_pipeline_tool

# 🤖 Create LLM Agent using the tool function
def create_generator_agent():
    return LlmAgent(
        name="PipelineGeneratorAgent",
        model="gemini-2.0-flash",
        tools=[generate_pipeline_tool],
        instruction=(
            "You generate CI/CD pipelines from the details provided. "
            "Display the generated pipeline code. "
        )
    )
