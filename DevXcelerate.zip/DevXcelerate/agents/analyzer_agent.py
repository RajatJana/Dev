from google.adk.agents import LlmAgent
from tools.analyzer_tool import analyzer_tool

# 🤖 Create LLM Agent using the tool function
def create_analyzer_agent():
    return LlmAgent(
        name="AnalyzerAgent",
        model="gemini-2.0-flash",
        tools=[analyzer_tool],
        instruction=(
            "You analyze the project from provided git link. "
            "Display the complete analysis report(Not in JSON Format). "
        )
    )
