import os
import google.generativeai as genai
from google.adk.agents import LlmAgent, LoopAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

# ✅ Hardcoded Gemini API key
api_key = "API_KEY_HERE"  # Replace this
os.environ["GOOGLE_API_KEY"] = api_key
genai.configure(api_key=api_key)


class PipelineRefiner:
    def __init__(self, pipeline_code: str):
        self.pipeline_code = pipeline_code
        self.session = InMemorySessionService()
        self.session_id = "session-001"
        self.user_id = "ci-user"

        self.generator = LlmAgent(
            name="RefinerAgent",
            model="gemini-2.0-flash",
            instruction=(
                "Pass the initial file to DevOpsExpert for feedback. "
                "Always pass user feedback to DevOpsExpert for analysis. "
                "Don't provide initial feedback. Always prioritize EndUserAgent feedback. "
                "Stop when 'approved'. Take user feedback and update the pipeline. "
                "Then send the new version to DevOpsExpert for review."
            )
        )

        self.devops = LlmAgent(
            name="DevOpsExpert",
            model="gemini-2.0-flash",
            instruction=(
                "Review pipelines and suggest improvements. Stop when user approves. "
                "Always respond when Generator sends an update."
            )
        )

        self.loop = LoopAgent(
            name="PipelineRefinementLoop",
            sub_agents=[self.generator, self.devops],
            max_iterations=1
        )

        self.runner = Runner(
            agent=self.loop,
            session_service=self.session,
            app_name="ci_cd_pipeline_refiner"
        )

    async def _read_response_split(self, generator) -> dict:
        output = {"refiner": "", "devops": ""}
        turn = 0  # First turn is RefinerAgent, second is DevOpsExpert

        async for event in generator:
            if event.content and event.content.parts:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        agent = "refiner" if turn % 2 == 0 else "devops"
                        output[agent] += part.text.strip() + "\n"
            turn += 1

        return {k: v.strip() for k, v in output.items()}



    async def start_session(self) -> dict:
        await self.session.create_session(
            user_id=self.user_id,
            session_id=self.session_id,
            app_name="ci_cd_pipeline_refiner"
        )
        generator = self.runner.run_async(
            user_id=self.user_id,
            session_id=self.session_id,
            new_message=types.Content(
                role="user",
                parts=[types.Part(text=f"Initial pipeline draft:\n\n{self.pipeline_code}")]
            )
        )
        return await self._read_response_split(generator)

    async def user_feedback(self, feedback: str) -> dict:
        generator = self.runner.run_async(
            user_id=self.user_id,
            session_id=self.session_id,
            new_message=types.Content(
                role="user",
                parts=[types.Part(text=feedback)]
            )
        )
        return await self._read_response_split(generator)

