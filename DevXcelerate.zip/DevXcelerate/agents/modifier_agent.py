from google.adk.agents import LlmAgent
from tools.modifier_tool import modifier_tool

# 🤖 Create LLM Agent using the tool function
def create_modifier_agent():
    return LlmAgent(
        name="ModifierAgent",
        model="gemini-2.0-flash",
        tools=[modifier_tool],
        instruction=(
            "You modify the pipeline code as per user request. "
            "Display the updated pipeline code. "
        )
    )