from google.adk.agents import LlmAgent
from tools.converter_tool import convert_pipeline_tool


# 🤖 Create LLM Agent using the tool function
def create_pipeline_converter_agent():
    return LlmAgent(
        name="PipelineConverterAgent",
        model="gemini-2.0-flash",
        tools=[convert_pipeline_tool],
        instruction=(
            "You convert CI/CD pipelines from one technology to another. "
            "Display the converted pipeline code. Always explain your changes clearly."
        )
    )
