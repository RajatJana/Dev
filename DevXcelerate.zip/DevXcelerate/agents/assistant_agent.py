from google.adk.agents import LlmAgent
from tools.assistant_tool import assistant_tool

# 🤖 Create LLM Agent using the tool function
def create_assistant_agent():
    return LlmAgent(
        name="AssistantAgent",
        model="gemini-2.0-flash",
        tools=[assistant_tool],
        instruction=(
            "answer it naturally in detail."
        )
    )
