import google.generativeai as genai

from services.converter_service import ConverterService



# 🔧 Tool function for pipeline conversion
def convert_pipeline_tool(pipeline_yaml: str, source_tech: str, target_tech: str, input_os: str) -> str:
    print("🔧 In convert_pipeline_tool function")
    print("source_tech:", source_tech)
    print("target_tech:", target_tech)

    converter = ConverterService()
   
    source = source_tech.lower().replace(" ", "").replace("_", "")
    target = target_tech.lower().replace(" ", "").replace("_", "")
    if "azure" in source and "jenkins" in target:
        return converter.convert_azure_to_jenkins(pipeline_yaml, input_os)
    elif "jenkins" in source and "azure" in target:
        return converter.convert_jenkins_to_azure(pipeline_yaml, input_os)
    else:
        raise ValueError(f"Unsupported conversion from {source_tech} to {target_tech}")