import google.generativeai as genai
from PromptHub import load_prompt

# ====== CONFIG ======
genai.configure(api_key="API_KEY_HERE")  # <-- Replace with your actual API key
model = genai.GenerativeModel("gemini-2.0-flash")

# ====== ======== ======
def modifier_tool(code: str, user_input: str) -> str:

    template = load_prompt("modifier_prompt.txt")
    prompt = template.format(code=code, user_input=user_input)
    response = model.generate_content(prompt)
    return response.text.strip()