import google.generativeai as genai
from PromptHub import load_prompt


# ====== CONFIG ======
genai.configure(api_key="API_KEY_HERE")  # <-- Replace with your actual API key
model = genai.GenerativeModel("gemini-2.0-flash")

# ====== STEP: Generate CI/CD Pipeline Specification ======
def generate_spec(detected_info, repo_link, user_additions):
    template = load_prompt("generate_spec_prompt.txt")
    prompt = template.format(detected_info=detected_info, repo_link=repo_link, user_additions=user_additions or "None")
    response = model.generate_content(prompt)
    return response.text

# ====== STEP: Generate CI/CD Pipeline ======
def generate_pipeline_tool(detected_info: str, repo_link: str, user_additions: str, ci_cd_tool: str, os: str) -> str:
    specification = generate_spec(detected_info, repo_link, user_additions)
    template = load_prompt("generate_pipeline_prompt.txt")
    prompt = template.format(detected_info=detected_info, repo_link=repo_link, user_additions=user_additions or "None", ci_cd_tool=ci_cd_tool, specification=specification, os=os)
    response = model.generate_content(prompt)
    return response.text