from PromptHub import load_prompt
import google.generativeai as genai
import os

# Set up API key, possibly from environment or securely managed secrets
os.environ["GOOGLE_API_KEY"] = "API_KEY_HERE"
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

def assistant_tool(code: str, user_input: str) -> str:
    """Agent tool for rerunning code with conversational context."""
    model = genai.GenerativeModel("gemini-2.0-flash")

    template = load_prompt("assistant_prompt.txt")
    prompt = template.format(code=code, user_input=user_input)
    response = model.generate_content(prompt)
    return response.text.strip()
