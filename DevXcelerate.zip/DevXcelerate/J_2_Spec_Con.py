from langchain.schema import Document
# from langchain_community.vectorstores import FAISS # No longer needed
from langchain_huggingface import HuggingFaceEmbeddings # Still used for get_embeddings, but get_embeddings isn't strictly needed for the LLM call directly
from langchain_core.prompts import PromptTemplate
# from langchain_core.prompts import FewShotPromptTemplate # No longer needed
from transformers import AutoTokenizer, AutoModel
from langchain_google_genai import ChatGoogleGenerativeAI

import faiss # No longer directly used for LLM part
import torch
import yaml
import numpy as np
import re
import json
import os
import Utility as util # Assuming Utility.py contains load_model

# --- Helper Functions (Remains largely the same, but crucial for extracting stage content) ---

def extract_stages(pipeline_str, pipeline_type="azure"):
    """
    Extracts stages from a pipeline string based on its type (Azure YAML or Jenkinsfile).
    For Jenkins, it extracts the name and the content within the stage block.
    """
    stages = []
    additional_attributes = {}

    if pipeline_type == "azure":
        pipeline_data = yaml.safe_load(pipeline_str)
        additional_attributes = {key: value for key, value in pipeline_data.items() if key not in {"stages", "jobs", "steps"}}
        if "stages" in pipeline_data:
            stages = pipeline_data["stages"]
        elif "jobs" in pipeline_data:
            for job in pipeline_data["jobs"]:
                stage_name = guess_stage_name(job)
                stages.append({"stage": stage_name, "jobs": [job]})
        elif "steps" in pipeline_data:
            for step in pipeline_data["steps"]:
                stage_name = guess_stage_name(step)
                stages.append({"stage": stage_name, "steps": [step]})
    elif pipeline_type == "jenkins":
        # Robust regex for capturing the entire content of a stage block.
        # This iterates through stage declarations and finds the matching closing brace.
        stage_declarations = re.finditer(r"stage\s*\('([^']+)'\)\s*\{", pipeline_str)
        
        for match in stage_declarations:
            stage_name = match.group(1).strip()
            start_index_of_brace = match.end() - 1 # Position of the opening '{'
            
            # Find the matching closing brace for this stage
            brace_count = 1
            content_end_index = start_index_of_brace + 1
            
            while content_end_index < len(pipeline_str) and brace_count > 0:
                char = pipeline_str[content_end_index]
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                content_end_index += 1
            
            if brace_count == 0: # Found matching closing brace
                # Extract content including the curly braces
                stage_content_raw = pipeline_str[start_index_of_brace : content_end_index]
                stages.append({"stage": stage_name, "content": stage_content_raw.strip()})
            else:
                # Fallback if matching brace not found (e.g., malformed pipeline)
                print(f"Warning: Could not find matching brace for stage '{stage_name}'. Extracting partial content.")
                # Attempt to extract until next stage or end of file as a fallback
                next_stage_match = re.search(r"stage\s*\('[^']+'\)\s*\{", pipeline_str[content_end_index:])
                if next_stage_match:
                    fallback_end = content_end_index + next_stage_match.start()
                    stage_content_raw = pipeline_str[start_index_of_brace : fallback_end]
                else:
                    stage_content_raw = pipeline_str[start_index_of_brace:]
                stages.append({"stage": stage_name, "content": stage_content_raw.strip()})

    return stages, additional_attributes


def guess_stage_name_from_display_name(step):
    """
    Guesses stage name from 'displayName' in Azure DevOps steps.
    """
    if 'displayName' in step:
        return step['displayName']
    if 'script' in step and isinstance(step['script'], str):
        display_name_match = re.search(r'displayName:\s*(.+)', step['script'])
        if display_name_match:
            return display_name_match.group(1).strip()
    return None

def guess_stage_name_from_keywords(step):
    """
    Guesses stage name from keywords in Azure DevOps steps as a fallback.
    """
    keywords = ["build", "test", "deploy", "release", "package"]
    if isinstance(step, str): # ensure step is a string for .lower()
        for keyword in keywords:
            if keyword in step.lower():
                return keyword.capitalize()
    elif isinstance(step, dict): # if step is a dictionary (common in Azure YAML)
        for key, value in step.items():
            if isinstance(value, str):
                for keyword in keywords:
                    if keyword in value.lower():
                        return keyword.capitalize()
    return "Unknown"

def guess_stage_name(step):
    """
    Combines display name and keyword guessing for Azure DevOps stages.
    """
    stage_name = guess_stage_name_from_display_name(step)
    if stage_name:
        return stage_name
    return guess_stage_name_from_keywords(str(step)) # Convert dict to string for keyword guessing

# Function to create embeddings (still here, but not used for LLM prompting in this version)
# You could remove this if you only need it for the LLM part of the original code
def get_embeddings(text):
    """
    Generates embeddings for a given text using a pre-trained Sentence Transformer model.
    """
    tokenizer = AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    inputs = tokenizer(text, return_tensors='pt', padding=True, truncation=True)
    
    with torch.no_grad():
        embeddings = model(**inputs)
    return embeddings.last_hidden_state.mean(dim=1).squeeze().numpy()

# --- MODIFIED: create_chain for direct LLM prompting ---
def create_direct_llm_chain(input_type):
    """
    Creates an LLM chain for generating pipeline specifications without few-shot examples.
    The prompt directly instructs the LLM on the desired output format.
    """
    # CRITICAL CHANGE: This single PromptTemplate must contain all instructions.
    # It explains the task, the desired JSON structure, and then takes the user's input.
    prompt_template_str = """
You are an expert in DevOps pipelines. Your task is to convert the provided Jenkins Pipeline code into a structured JSON specification.

The output JSON must be an array of objects. Each object in the array represents a Jenkins stage and must contain the following keys:
- "stage": (string) The name of the Jenkins stage.
- "steps": (array) An array of objects, where each object represents a step within that stage. Each step object must contain:
  - "script": (string) The full Groovy script or shell command(s) for that specific step, preserving line breaks or a general command of the step which can be used as common across all technologies.
  - "displayName": (string) A concise display name for the step, which for simplicity can be the same as the parent stage's name if not explicitly provided otherwise in the Jenkinsfile.
- Any more section if required like enviroment variables or any other field that may needed.
Here is the Jenkins Pipeline code to convert:

---JENKINSFILE_START---
{user_input}
---JENKINSFILE_END---

Please provide only the JSON output.
"""

    prompt = PromptTemplate(
        template=prompt_template_str,
        input_variables=["user_input"]
    )
   
    os.environ["GOOGLE_API_KEY"] = "AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ" # <<< IMPORTANT: Replace with your actual API key
    if not os.environ.get("GOOGLE_API_KEY"):
        raise ValueError("GOOGLE_API_KEY environment variable not set.")

    llm = util.load_model("gemini-2.0-flash") # Load your LLM model

    def chain_func(input_text):
        formatted_input = prompt.format(user_input=input_text)
        return llm.invoke(formatted_input).content
    
    return chain_func

# --- MODIFIED: generate_spec_from_code_j for direct LLM prompting ---
def generate_spec_from_code_j(pipeline_str, pipeline_type="jenkins"):
    """
    Generates a pipeline specification from the given pipeline code (Azure YAML or Jenkinsfile)
    using direct LLM prompting without few-shot examples or FAISS.
    """
    print(f"Generating spec for {pipeline_type} pipeline using direct LLM prompting.")

    # Tokenizer and Model for embeddings are not strictly needed for the LLM call itself
    # but might be present in your Utility.py or used elsewhere.
    # If not used, you can remove these lines for a leaner setup.
    tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L6-v2')
    model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L6-v2')

    if pipeline_type != "jenkins":
        # This function is specifically tailored for Jenkins in this version.
        raise ValueError("This version of the function only supports 'jenkins' pipeline type.")

    # Extract stages from the pipeline string
    pipeline_stages, additional_attributes = extract_stages(pipeline_str, pipeline_type)

    # Combine all stage contents into a single input string for the LLM.
    # Each 'content' field now holds the entire stage block (e.g., 'stage('Build') { ... }').
    combined_stage_content = "\n\n".join([stage["content"] for stage in pipeline_stages])
    
    if not combined_stage_content.strip():
        print("Warning: No stages extracted or combined content is empty.")
        return json.dumps([]) # Return empty JSON array if no stages found

    print("Combined stage content for LLM input: \n", combined_stage_content)

    # Create the direct LLM chain
    # input_type is passed to the prompt's template string for context.
    chain = create_direct_llm_chain(input_type="Jenkins Pipeline Code")

    # Generate specification using the chain
    specification_str = chain(combined_stage_content)
    print("Generated Specification String: \n", specification_str)
    
    # Attempt to parse the output as JSON for verification
    try:
        parsed_spec = json.loads(specification_str)
        # Optional: Add additional_attributes if they were relevant for the whole pipeline
        # (though your example output doesn't show them for stages)
        # final_spec = {"pipeline_spec": parsed_spec, "additional_attributes": additional_attributes}
        # return json.dumps(final_spec, indent=2)
        return json.dumps(parsed_spec, indent=2) # Pretty print for readability
    except json.JSONDecodeError as e:
        print(f"\nError decoding JSON output from LLM: {e}")
        print("LLM output was not valid JSON. Returning raw string.")
        return specification_str

