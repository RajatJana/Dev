import json
import faiss
import numpy as np
import torch
import os
import Utility as util
#import ExtractEmbeddingText as EET
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from transformers import AutoTokenizer, AutoModel
import prompt_spec 


#Function to escape braces in JSON string
def escape_braces(json_string):
    return json_string.replace("{","{{").replace("}","}}")

# Input pipeline specification
#with open ('C:/Gen AI/Input/json_spec_1.json','r') as f:
 # pipeline_specification  = json.load(f)

# Load examples from JSON
few_shot_examples = util.load_json("Yaml_Ex_v1.json")
example_inputs = [ escape_braces(example["specification"]) for example in few_shot_examples]
#Create Faiss index
index= util.create_faiss_index(example_inputs)

# Function to perform semantic search
def query_faiss_index(input_text, index, few_shot_examples, k=2):
    input_embedding = util.get_embeddings(input_text)
    distances, indices = index.search(np.array([input_embedding]), k)
    relevant_examples = [few_shot_examples[i] for i in indices[0]]
    return relevant_examples

#Function to extract stages from the pipeline specification
def extract_stages(pipeline_spec):
    stages=[]
    if (isinstance(pipeline_spec,list)):
      for item in pipeline_spec:
        if isinstance(item,dict) and "stages" in item:
            stages.extend(item["stages"])
  
    stages_str = json.dumps(stages,indent=4)
    print("extract stages ",stages_str)
    return stages_str

def create_chain(relevant_examples,input_text,stages):
    formatted_examples = [
    {
        "specification":escape_braces(example["specification"]),
        "yaml":escape_braces(example["yaml"])
         
    } for example in relevant_examples 
    ]
    
    #Define the FewShotTemplate using the retrieved examples
    example_prompt=PromptTemplate(template="""specification:{specification}\n yaml:{yaml}\n""",input_variables=["specification","stages"])
    template= FewShotPromptTemplate(
        examples=formatted_examples,
        example_prompt=example_prompt,
        prefix= prompt_spec.yamlPrompt_TRAI,
        suffix="specification:{specification}\n output_example\n output_docs:",
        input_variables=["specification","stages"]
    )  
        # Define the FewShotTemplate using the retrieved examples
        
    # Define the chain function
    def chain(input_text,stages):
        llm = util.load_model("gemini-2.0-flash")
        escaped_input_text = escape_braces(input_text)
        print("input_text:",input_text)
        print("escaped_input_text:",escaped_input_text)
        escaped_stages = escape_braces(stages)
        print("stages:",stages)
        print("escaped_stages:",escaped_stages)
        #formatted_input = template.format(input_example=escaped_input_text,stages=escaped_stages_str)
        formatted_input = template.format(specification=input_text,stages= stages)
        return llm.invoke(formatted_input).content
        
    return chain

# Function to convert pipeline specification to Jenkins pipeline
def convert_specification_to_code(pipeline_specification):
    # Extract stages from the pipeline
    stages= extract_stages(pipeline_specification)
    input_text = json.dumps(pipeline_specification)
    print("input_text ",input_text)
    relevant_examples = query_faiss_index(input_text,index, few_shot_examples)
    chain = create_chain(relevant_examples,input_text,stages)
    pipeline = chain(input_text,stages)
    return pipeline

   
#input_text = json.dumps(pipeline_specification,indent=4)
# Perform semantic search to find relevant examples
#relevant_examples = query_faiss_index(input_text,index, few_shot_examples)
# Convert the pipeline specification to Jenkins pipeline
#pipeline_code = convert_specification_to_code(pipeline_specification)
#print("Axure Pipeline:\n", pipeline_code)



       
       