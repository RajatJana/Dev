import os
import json
import shutil
import tempfile
import networkx as nx
import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple
from git import Repo, GitCommandError
from rich import print
from rich.table import Table
from pyvis.network import Network  # PyVis for visualization
import torch
from rich.console import Console
from io import StringIO

def clone_repo(repo_url: str) -> str:
    temp_dir = tempfile.mkdtemp()
    try:
        print(f"[cyan]Cloning repository from {repo_url}...[/cyan]")
        Repo.clone_from(repo_url, temp_dir)
        print(f"[green]Repository cloned to {temp_dir}[/green]")
        return temp_dir
    except GitCommandError as e:
        print(f"[red]Git clone failed: {e}[/red]")
        shutil.rmtree(temp_dir)
        raise

def detect_technologies(repo_path: str) -> Dict[str, List[str]]:
    techs = {"Java+Maven": [], "Node.js+npm": [], "Python+pip": []}
    for root, dirs, files in os.walk(repo_path):
        if "pom.xml" in files:
            techs["Java+Maven"].append(root)
        elif "package.json" in files:
            techs["Node.js+npm"].append(root)
        elif "requirements.txt" in files or any(f.endswith(".py") for f in files):
            techs["Python+pip"].append(root)
    return {k: v for k, v in techs.items() if v}

def extract_java_dependencies(services: List[str]) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    service_names = {}
    dependencies = {}

    for path in services:
        try:
            tree = ET.parse(os.path.join(path, "pom.xml"))
            root = tree.getroot()
            ns = {'m': 'http://maven.apache.org/POM/4.0.0'}

            artifact = root.find("m:artifactId", ns)
            if artifact is None:
                continue
            service_name = artifact.text
            service_names[path] = service_name
            dependencies[service_name] = []

            for dep in root.findall(".//m:dependencies/m:dependency", ns):
                group_id = dep.find("m:groupId", ns)
                artifact_id = dep.find("m:artifactId", ns)
                if group_id is not None and artifact_id is not None:
                    dependencies[service_name].append(artifact_id.text)
        except Exception as e:
            print(f"[red]Failed to parse pom.xml in {path}: {e}[/red]")

    # Filter to only internal dependencies
    internal = set(dependencies.keys())
    filtered = {svc: [d for d in deps if d in internal] for svc, deps in dependencies.items()}
    return filtered, service_names

def build_dependency_graph(dep_map: Dict[str, List[str]]) -> nx.DiGraph:
    graph = nx.DiGraph()
    for svc, deps in dep_map.items():
        graph.add_node(svc)
        for dep in deps:
            graph.add_edge(dep, svc)  # Edge from dependency to dependent
    return graph

def sort_microservices(graph: nx.DiGraph) -> List[str]:
    try:
        return list(nx.topological_sort(graph))
    except nx.NetworkXUnfeasible:
        cycles = list(nx.simple_cycles(graph))
        print(f"[red]Cyclic dependencies detected: {cycles}[/red]")
        raise

def visualize_with_pyviz(graph: nx.DiGraph, filename: str = "dependency_graph.html"):
    net = Network(height="750px", width="100%", directed=True)
    net.toggle_physics(False)

    for node in graph.nodes():
        net.add_node(node, label=node)

    for source, target in graph.edges():
        net.add_edge(source, target)

    print(f"[cyan]Generating interactive graph: {filename}[/cyan]")
    html_content = net.generate_html()
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)

def get_dependency_map_output(dep_map: Dict[str, List[str]]) -> str:
    output = "\n[bold yellow]Dependency Map:[/bold yellow]\n"
    
    # Create a Rich table
    table = Table(title="Microservice Dependencies")
    table.add_column("Microservice", style="bold")
    table.add_column("Depends On", style="dim")
    for svc, deps in dep_map.items():
        table.add_row(svc, ", ".join(deps) if deps else "None")
    
    # Capture table as string using Console and StringIO
    buffer = StringIO()
    console = Console(file=buffer, force_terminal=True)
    console.print(table)
    
    # Combine output
    output += buffer.getvalue()
    return output

def output_results(techs: Dict[str, List[str]], build_order: List[str], dep_map: Dict[str, List[str]]):
    tech_output = "\n[bold cyan]Technologies Detected:[/bold cyan]"
    for tech, services in techs.items():
        tech_output += f"- {tech}: {len(services)} services"

    build_output = "\n[bold green]Build Order (Topologically Sorted):[/bold green]"
    for i, svc in enumerate(build_order, 1):
        build_output += f"{i}. {svc}"

    print("\n[bold yellow]Dependency Map:[/bold yellow]")
    table = Table(title="Microservice Dependencies")
    table.add_column("Microservice", style="bold")
    table.add_column("Depends On", style="dim")
    for svc, deps in dep_map.items():
        table.add_row(svc, ", ".join(deps) if deps else "None")
    print(table)

    # ATS Phasing
    ats_phases = {}
    levels = {}
    for svc in build_order:
        if not dep_map[svc]:
            levels[svc] = 1
        else:
            levels[svc] = 1 + max(levels.get(dep, 1) for dep in dep_map[svc])

    for svc, lvl in levels.items():
        ats_phases.setdefault(f"phase_{lvl}", []).append(svc)

    result = {
        "technologies": list(techs.keys()),
        "build_order": build_order,
        "dependency_map": dep_map,
        "ats_phases": ats_phases
    }

    print("\n[bold magenta]ATS Phasing Output:[/bold magenta]")
    for phase, services in ats_phases.items():
        print(f"{phase}: {services}")

    print("\n[bold magenta]JSON Output:[/bold magenta]")
    print(json.dumps(result, indent=2))
    return tech_output + build_output + get_dependency_map_output(dep_map) 


def extract_dependency(repo_url):
    
    try:
        repo_path = clone_repo(repo_url)
        techs = detect_technologies(repo_path)

        if "Java+Maven" in techs:
            dep_map, _ = extract_java_dependencies(techs["Java+Maven"])
            graph = build_dependency_graph(dep_map)
            build_order = sort_microservices(graph)
            result = output_results(techs, build_order, dep_map)
            visualize_with_pyviz(graph)
            return result
        else:
            return None

    finally:
        print("within finally")
        

