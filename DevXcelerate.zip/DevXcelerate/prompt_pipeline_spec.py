pipelinePrompt = """ ### Task
                  Convert an DevOpspipeline [input]{input}[/input]into a pipeline specification using which DevOps pipeline code can be written in any technology.
                  
            """

pipelinePrompt_TRAI = """ ### Task
                        Convert a DevOps YAML pipeline code [input]{input}[/input]into thepipeline specification.
                        
                    Below is an instruction that describes a task. Write a response that appropriately completes the request.
                                        
                    ### Instructions
                        - Provide a DevOps YAML pipeline code [input]{input}[/input] that includes stages, jobs, tasks, and steps in a clear and structured format
                        - Ensure the input YAML pipeline contains all relevant elements, including any triggers, pool definitions, and step details, in the correct sequence..
                        - Use docker image only when explicitly mentioned otherwise do not use docker  
                        - Additional elements present in the input YAML should be clearly identifiable and accurately formatted for extraction.
                        - Extract all step,task,script from the given input file and present them in the structured format output.
                        - For each step/task/script , a stage needs to be created in output json.
                        - Ensure that all step/task/script of the input files are included in the output.
                        - Repeat this format for all tep/task/script and tasks in the input file. 
                        - If the input file includes additional steps ensure they are captured accurately in the output. 
                        - Do not omit any step that present in input file.Do not miss any steps.
                        - Maintain the correct sequence of tasks as given in the input.
                        - If a particular stage/task/script is not present in input file, then it will not be present in the output.
                        - Generate only the specification json,do not generate any additional content
                        - Do not include any explanation or improvement,only generate the specification
                    
                    ###output
                         The output should:
                         -Extract all trigger,pool,stages, jobs, tasks, and steps from the input YAML and convert them into a structured JSON specification.
                        - Ensure the JSON output replicates the build and deployment logic from the input YAML accurately.
                        - Ensure the code specification replicates all stages from the input pipeline.
                        - Include every stage, job, task, and step from the input YAML without omission or modification.
                        - Maintain the correct sequence of elements as specified in the input YAML.
                        - Handle missing elements gracefully by excluding any stage, job, task, or step that is not present in the input YAML.
                        - Generate only one JSON specification in the output�no additional text, alternative specifications, or unrelated content.
                        - Avoid generating any unrelated code (e.g., Python) or extraneous comments; focus solely on producing the JSON pipeline specification.
                        - Generate only one specification which is most appropriate.
                        - Do not generate multiple specifications.
                        - Do not generate any additional text apart from the specification.
                        - Do not generate any code.Only generate the specification
                        - DO not write any additional text or explanation.
                     """


codePrompt_TRAI ="""Convert the given pipeline specification into a Jenkinsfile. Ensure the following considerations:
                    - Do not put '''groovy at the top of the code                                    
                    - No need to mention Maven tool details in the Maven build stage.
                    - Please do not merge two stages.Like Maven build and Tomcat deploy,these  will be two different stages,these will not be merged.
                    - Please do not repeat the same step.
                    - Follow the same deployment step as mentioned in specification.
                    - If the OS [input]{os}[/input] is Windows, for any shellscript, please use bat instead of sh.
                    - If the OS  [input]{os}[/input] is Windows, then show only windows compatable code, no need to show code for unix
                    - If the OS  [input]{os}[/input] is Windows,Instead of using £ before environment variables, use %.Remove $ sign
                    - Maintain proper formatting and ensure compatibility with Jenkins syntax.
                    - For copy,please use copy instead of xcopy
                    - Remove '''grrovy from the top of the code
                    
                    
                  """
embeddingPrompt_TRAI ="""Convert user input into embedding-friendly format,ensuring logical reordering. Ensure the following considerations:
                    - Generate embedding text for short user input as well.                                  
                    - Example Input: "Generate a pipeline to build a java maven application and deploy in tomcat"
                      Example Output: "Generating a pipeline,Building a java maven application,Deploying in tomcat"
                    
                    
                  """

                  


