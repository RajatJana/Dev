import streamlit as st
import pandas as pd
import json

st.set_page_config(page_title="Stage Tool Configurator", layout="centered")
st.title("🛠️ Pipeline Stage Configurator")

# Tool options
tool_options = {
    "Build": ["Maven", "Gradle"],
    "Test": ["JUnit", "Selenium"],
    "Deploy": ["Docker", "Kubernetes", "Azure DevOps"],
    "Monitor": ["Prometheus", "Grafana"]
}

if "stage_items" not in st.session_state:
    st.session_state.stage_items = []

# Add stage
with st.expander("➕ Add a Stage", expanded=True):
    stage = st.selectbox("Select Stage", [""] + list(tool_options.keys()), key="stage_select")
    if stage:
        tool = st.selectbox("Select Tool", [""] + tool_options.get(stage, []), key="tool_select")
        if tool and st.button("✅ Add Stage"):
            st.session_state.stage_items.append({"Stage": stage, "Tool": tool})
            st.rerun()

if st.session_state.stage_items:
    st.subheader("📋 Final Configuration")

    for i, item in enumerate(st.session_state.stage_items):
        cols = st.columns([6, 1, 1])
        cols[0].markdown(f"**{item['Stage']}** — {item['Tool']}")
        if i > 0 and cols[1].button("↑", key=f"up_{i}"):
            st.session_state.stage_items[i], st.session_state.stage_items[i-1] = \
                st.session_state.stage_items[i-1], st.session_state.stage_items[i]
            st.rerun()
        if i < len(st.session_state.stage_items) - 1 and cols[2].button("↓", key=f"down_{i}"):
            st.session_state.stage_items[i], st.session_state.stage_items[i+1] = \
                st.session_state.stage_items[i+1], st.session_state.stage_items[i]
            st.rerun()

    # Debug JSON
    st.subheader("🧪 Debug: JSON Configuration")
    st.json(st.session_state.stage_items)
else:
    st.info("Click '➕ Add a Stage' to start configuring your pipeline.")