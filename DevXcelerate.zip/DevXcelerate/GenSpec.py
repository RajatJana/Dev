from langchain.schema import Document
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import re
import json
import os
import torch
import streamlit as st
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate
import prompt_spec as promptPipeline # Assuming this contains your pipelinePrompt_TRAI
from langchain_google_genai import ChatGoogleGenerativeAI
from transformers import AutoTokenizer, AutoModel
import Utility as util # Assuming this contains get_embeddings and remove_prefix_suffix
from langchain_ollama.llms import OllamaLLM # Keeping this for local model option

# Load few-shot examples
examples_path = os.path.join('C:/Users/RajatJana/Desktop/DevXcelerate/Examples', 'Gen_Ex_v1.json')
with open(examples_path, 'r') as f:
    few_shot_examples = json.load(f)

# Initialize embedding model
# Ensure this model is loaded and available for util.get_embeddings
embedding_model = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
# You might need to pass embedding_model to util.get_embeddings if it's not a global singleton there.
# For simplicity, assuming util.get_embeddings internally handles model loading or uses a globally accessible one.

def format_stage_tools(stage, tools):
    """Formats stage and tools into a consistent string for embedding."""
    if isinstance(tools, str):
        tools = [tools] # Ensure tools is always a list for joining
    return f"Stage: {stage}, Tool: {','.join(tools)}"

# Create embeddings and FAISS index
example_texts = [format_stage_tools(ex["Stage"], ex["Tool"]) for ex in few_shot_examples]
example_embeddings = [util.get_embeddings(text) for text in example_texts] # Corrected: use text here
example_mapping = {i: few_shot_examples[i] for i in range(len(few_shot_examples))}

# Create and Populate Faiss Index
dimension = example_embeddings[0].shape[0]
index = faiss.IndexFlatL2(dimension)
embedding_matrix = np.array(example_embeddings).reshape(-1, dimension)
index.add(embedding_matrix)

def extract_stages_tools(stage_tools_data):
    """
    Extracts stages and tools from stage_tools_data, which is expected to be
    a list of strings formatted as 'Stage: X Tool: Y'.
    Returns a list of dictionaries like [{"stage": "X", "tool": "Y"}].
    """
    extracted_data = []
    
    # This function is specifically for parsing the list of formatted strings from user_input's stage_tools
    # It assumes the input `stage_tools_data` here is like ["Stage: Build Tool: Maven", ...]
    if isinstance(stage_tools_data, list):
        data_string = " ".join(stage_tools_data) # Join for a single regex pass
    elif isinstance(stage_tools_data, str):
        data_string = stage_tools_data
    else:
        print(f"Unsupported data type for extract_stages_tools: {type(stage_tools_data)}")
        return extracted_data

    matches = re.findall(r"Stage:\s*(.*?)\s*Tool:\s*(\S+)", data_string)

    for match in matches:
        stage, tool = match
        extracted_data.append({"stage": stage.strip(), "tool": tool.strip()})

    return extracted_data

def get_relevant_examples(parsed_stage_tools_from_user_input):
    """
    Get relevant examples by prioritizing exact matches from few_shot_examples.
    If no exact match, fall back to FAISS (nearest neighbor).
    Returns a list of unique relevant example dictionaries.
    """
    relevant_examples = []
    seen_examples_hashes = set() # To prevent adding duplicate examples

    for item in parsed_stage_tools_from_user_input:
        stage = item['stage']
        tool = item['tool']
        
        found_exact_match = False
        # 1. Try to find an exact match in few_shot_examples
        for ex in few_shot_examples:
            # Normalize tools from example (can be string or list)
            ex_tool_list = [t.lower() for t in (ex["Tool"] if isinstance(ex["Tool"], list) else [ex["Tool"]])]
            current_tool_lower = tool.lower()

            # Check if stage matches AND the user's tool is one of the example's tools
            if ex["Stage"].lower() == stage.lower() and current_tool_lower in ex_tool_list:
                # Use json.dumps with sort_keys to create a consistent hash for set
                ex_hash = json.dumps(ex, sort_keys=True)
                if ex_hash not in seen_examples_hashes:
                    relevant_examples.append(ex)
                    seen_examples_hashes.add(ex_hash)
                found_exact_match = True
                break
        
        # 2. If no exact match, use FAISS as a fallback
        if not found_exact_match:
            try:
                query_text = format_stage_tools(stage, tool)
                query_embedding = util.get_embeddings(query_text).reshape(1, -1)
                distances, indices = index.search(query_embedding, 1) # Get top 1 closest
                
                closest_example = example_mapping[indices[0][0]]
                
                # Add to relevant_examples only if not already added
                closest_ex_hash = json.dumps(closest_example, sort_keys=True)
                if closest_ex_hash not in seen_examples_hashes:
                    relevant_examples.append(closest_example)
                    seen_examples_hashes.add(closest_ex_hash)
            except Exception as e:
                print(f"Error getting FAISS examples for {stage} with {tool}: {str(e)}")
                # Continue processing even if FAISS retrieval fails for one item
    
    return relevant_examples

def create_combined_chain(relevant_examples, extracted_data, git_repo_link):
    """
    Creates a LangChain chain for generating the combined specification.
    Takes relevant examples, the extracted dependency/build data, and the git repo link.
    """
    formatted_examples = [
        {
            "Stage": example["Stage"],
            "Tool": example["Tool"],
            "Specification": json.dumps(example["Specification"]) if isinstance(example["Specification"], dict) else example["Specification"]
        } 
        for example in relevant_examples
    ]

    example_prompt = PromptTemplate(
        input_variables=["Stage", "Tool", "Specification"],
        template="Stage: {Stage}\nTool: {Tool}\nSpecification: {Specification}"
    )

    # FewShotPromptTemplate to structure the examples and the main prompt
    template = FewShotPromptTemplate(
        examples=formatted_examples,  # Uses the prioritized relevant examples
        example_prompt=example_prompt,
        prefix=promptPipeline.pipelinePrompt_TRAI, # Your custom prefix prompt
        suffix="\n\nGenerate a complete pipeline specification that combines all these stages and tools:\n{input_description_for_llm}\n\nUser Provided Project Details (Dependency/Build Order):\n{extracted_data_for_prompt}\n\nGit Repository Link:\n{git_repo_link_for_prompt}\n\nComplete Specification:",
        input_variables=["input_description_for_llm", "extracted_data_for_prompt", "git_repo_link_for_prompt"],
        example_separator="\n---\n"
    )
    
    # Initialize the LLM (ensure GOOGLE_API_KEY is set in environment or handled)
    os.environ["GOOGLE_API_KEY"]="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ" # Example API key, secure this in production
    llm = ChatGoogleGenerativeAI(
          model="gemini-2.0-flash",
          temperature=0,
          max_tokens=None,
          timeout=None,
          max_retries=2
     )
    # For Ollama (local LLM), uncomment and configure if needed:
    # llm = OllamaLLM(model="llama3.2:latest", base_url="http://localhost:11434/")

    def chain(input_description_for_llm, extracted_data_for_prompt, git_repo_link_for_prompt):
        """
        The executable chain function that takes specific prompt inputs.
        """
        print(f"--- LLM Input Description ---\n{input_description_for_llm}")
        print(f"--- LLM Extracted Data ---\n{extracted_data_for_prompt}")
        print(f"--- LLM Git Repo Link ---\n{git_repo_link_for_prompt}")
        
        # Format extracted_data_for_prompt if it's a list of dicts for better readability in prompt
        if isinstance(extracted_data_for_prompt, list):
            extracted_data_formatted = json.dumps(extracted_data_for_prompt, indent=2)
        else: # Assume it's already a string or other simple format
            extracted_data_formatted = str(extracted_data_for_prompt)

        # Construct the final prompt
        prompt_str = template.format(
            input_description_for_llm=input_description_for_llm,
            extracted_data_for_prompt=extracted_data_formatted,
            git_repo_link_for_prompt=git_repo_link_for_prompt
        )
        
        print("\n--- Full Prompt Sent to LLM ---")
        print(prompt_str)
        
        response = llm.invoke(prompt_str)
        return response.content
        
    return chain

def generate_combined_specification(extracted_data, git_repo_link, user_input):
    """
    Generates a single combined specification for all stages and tools,
    incorporating dependency/build order and git repository link.
    """
    print(f"\n--- Inputs to generate_combined_specification ---")
    print(f"extracted_data (Dependency/Build Order): {json.dumps(extracted_data, indent=2) if isinstance(extracted_data, list) else extracted_data}")
    print(f"git_repo_link: {git_repo_link}")
    print(f"user_input (Stage & Tools): {json.dumps(user_input, indent=2)}")
    
    # Extract stage_tools list from the user_input dictionary
    stage_tool_list_from_user = user_input.get('stage_tools', [])
    print(f"stage_tool_list_from_user: {stage_tool_list_from_user}")
    
    # Convert the user's input list of dicts to the string format for `extract_stages_tools`
    # and subsequent embedding/matching with examples.
    # E.g., [{"stage": "Build", "tool": "Maven"}] -> ["Stage: Build Tool: Maven"]
    formatted_user_stage_tools_for_parsing = [f"Stage: {d['stage']} Tool: {d['tool']}" for d in stage_tool_list_from_user]
    
    # Parse these formatted strings into the [{"stage": "X", "tool": "Y"}] format
    # that `get_relevant_examples` expects for iteration.
    parsed_stage_tools_for_example_matching = extract_stages_tools(formatted_user_stage_tools_for_parsing)
    print(f"Parsed Stage/Tools for Example Matching: {parsed_stage_tools_for_example_matching}")
    
    # Get relevant examples (exact matches prioritized, then FAISS)
    relevant_examples = get_relevant_examples(parsed_stage_tools_for_example_matching)
    print(f"Relevant Examples retrieved for LLM: {relevant_examples}")
    
    # Create the input description for the LLM using the user's *original* stages and tools.
    # This ensures the LLM is always aware of the user's exact request.
    input_description_for_llm = "\n".join([
        f"Stage: {item['stage']}, Tool: {item['tool']}"
        for item in parsed_stage_tools_for_example_matching
    ])

    # Create the LangChain chain, passing all necessary original data
    chain = create_combined_chain(relevant_examples, extracted_data, git_repo_link)
    print("LangChain pipeline chain created.")
    
    try:
        # Invoke the chain, passing the specific inputs for the prompt
        specification = chain(
            input_description_for_llm,
            extracted_data, # This is your dependency/build order data
            git_repo_link   # This is your GitHub link
        )
        print("\n--- Specification Generated Successfully ---")
        return util.remove_prefix_suffix(specification)
    except Exception as e:
        print(f"\nError generating specification: {str(e)}")
        return f"Error generating specification: {str(e)}"

