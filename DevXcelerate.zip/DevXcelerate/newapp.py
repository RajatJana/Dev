# app.py
import streamlit as st
from new_gen import clone_repo, collect_key_files, ask_llm_to_detect_tech, generate_pipeline_with_llm, cleanup

st.set_page_config(page_title="LLM CI/CD Generator", layout="wide")

st.markdown("## 🤖 LLM-Powered CI/CD Pipeline Generator")
st.markdown("Automatically detect tech stack and generate a CI/CD pipeline from any public GitHub repo.")

if "project_path" not in st.session_state:
    st.session_state.project_path = None
if "tech_info" not in st.session_state:
    st.session_state.tech_info = None
if "repo_url" not in st.session_state:
    st.session_state.repo_url = None
if "ci_cd_tool" not in st.session_state:
    st.session_state.ci_cd_tool = None

if not st.session_state.tech_info:
    repo_url = st.text_input("🔗 GitHub Repository URL")
    ci_cd_tool = st.selectbox("🧱 Choose CI/CD Tool", ["Jenkins", "Azure YAML", "GitHub Actions"])

    if st.button("🔍 Analyze Repository"):
        with st.spinner("Cloning and analyzing repo..."):
            project_path, error = clone_repo(repo_url)
            if error:
                st.error(f"Failed to clone repository: {error}")
            elif not project_path:
                st.warning("Something went wrong.")
            else:
                files_data = collect_key_files(project_path)
                if not files_data:
                    st.warning("No valid config files found for analysis.")
                    cleanup(project_path)
                else:
                    st.session_state.tech_info = ask_llm_to_detect_tech(files_data, repo_url)
                    st.session_state.project_path = project_path
                    st.session_state.repo_url = repo_url
                    st.session_state.ci_cd_tool = ci_cd_tool
                    st.success("Technology analysis completed!")

# Step 2: Display analysis and ask for user additions
if st.session_state.tech_info:
    st.markdown("### 🧾 Tech Stack Analysis")
    st.code(st.session_state.tech_info)

    st.markdown("### ➕ Add Optional Custom CI/CD Instructions")
    user_additions = st.text_area("Custom instructions (e.g., add SonarQube, secrets scan)", "")

    if st.button("🚀 Generate CI/CD Pipeline"):
        with st.spinner("Generating pipeline using Gemini..."):
            pipeline_output = generate_pipeline_with_llm(
                st.session_state.tech_info,
                st.session_state.repo_url,
                st.session_state.ci_cd_tool,
                user_additions
            )
            st.markdown("### ✅ Generated CI/CD Pipeline")
            st.code(pipeline_output)
            cleanup(st.session_state.project_path)

        # Reset session state
        for key in ["project_path", "tech_info", "repo_url", "ci_cd_tool"]:
            st.session_state[key] = None