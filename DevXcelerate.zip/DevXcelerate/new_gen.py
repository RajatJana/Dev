import os
import shutil
import tempfile
import git
import google.generativeai as genai

# ====== CONFIG ======
genai.configure(api_key="AIzaSyApsAGYqoenhbUQ0Zw2tgzMWU_T-IaNHaQ")  # <-- Replace with your actual API key
model = genai.GenerativeModel("gemini-2.0-flash")


# ====== STEP 1: Clone GitHub Repo ======
def clone_repo(repo_url):
    temp_dir = tempfile.mkdtemp()
    try:
        git.Repo.clone_from(repo_url, temp_dir)
        return temp_dir, None
    except Exception as e:
        shutil.rmtree(temp_dir)
        return None, str(e)

# ====== STEP 2: Extract Representative Files ======
def collect_key_files(project_path, max_files=20, max_chars=5000):
    important_files = []
    extensions = ('.xml', '.gradle', '.txt', '.go', '.sln', '.mod', '.kts', '.yml', '.yaml', 'Dockerfile', '.tf', '.json', '.properties')
    
    for root, dirs, files in os.walk(project_path):
        for file in files:
            filepath = os.path.join(root, file)
            if file.endswith(extensions) or file == 'Dockerfile':
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if content.strip():
                            important_files.append({
                                "name": file,
                                "path": filepath,
                                "content": content[:max_chars]
                            })
                            if len(important_files) >= max_files:
                                return important_files
                except Exception:
                    continue
    return important_files

# ====== STEP 3: Detect Tech ======
def ask_llm_to_detect_tech(files_data, repo_url):
    file_texts = "\n\n".join([f"File: {f['path']}\nContent:\n{f['content']}" for f in files_data])
    prompt = f"""You are an expert DevOps architect.
Your task is to analyze the following project files from this repository: {repo_url}
You must return a **structured and detailed technical analysis**, suitable for building a CI/CD pipeline in tools like Jenkins, GitHub Actions, or Azure DevOps. Be precise, avoid assumptions, and only include what's supported by actual code/configs.
---
## 1. Description (Detailed Summary) 
Provide a multi-line, descriptive summary of the project. 
Include:
- Whether it's a monolithic or microservices-based project.
- If it is a multi-module Maven project, and whether a parent `pom.xml` exists.
- If the parent POM defines the build order and dependency management.
- Total number of modules and how many are actual microservices.
- Which modules produce a **WAR** or **JAR**, and which of them require deployment.
- If any modules include web services or REST APIs.
- Paths of modules generating WARs and needing deployment.
- Any infrastructure present (e.g., Docker, Kubernetes, Terraform).
- Any test or code quality tools found.
It should be a detailed description of the project.
---
## 2. Technologies & Frameworks Used List all core technologies detected (Java, Maven, Spring Boot, Jakarta EE, etc.)For each technology, provide:- Name- Where found (file name or path)- A one-line explanation of its role in the project
Format:
Java (Found in pom.xml) – Primary language used for the backend code
Maven (Found in root pom.xml) – Used as the build tool and dependency manager
Jakarta EE (Found via jakarta.* dependencies) – Used for web service APIs

---
## 3. Microservices, Modules & Build OrderIf the project is modular:- List all modules/microservices in order of build (based on `<dependency>` tags)- For each module, include: - Module Name - Packaging Type: `jar` or `war` - Relative Path - Dependencies (mention module names it depends on) - Whether this module needs to be deployed (e.g., if WAR)
Example Format:
Modules Detected:
1. Module: core-utils Type: jar Path: modules/core-utils Depends on: None Deploy Required: No
2. Module: user-service Type: war Path: services/user-service Depends on: core-utils Deploy Required: Yes


Build Order:
1. core-utils
2. user-service


Note:- If `<modules>` tag is missing in parent POM, use `<dependency>` tags to infer build order.- If parent POM handles build lifecycle, mention it clearly.
---
## 4. Tools Detected (Grouped Correctly)Group the tools into proper categories. For each tool, mention where it was found and its purpose.
Categories:- **Build Tools**: Maven, Gradle, etc.- **Languages & Frameworks**: Java, Spring Boot, Jakarta EE, etc.- **Testing Tools**: JUnit, Mockito, etc.- **Code Quality**: SonarQube, PMD, etc.- **Containerization**: Docker (Dockerfile), Podman, etc.- **Orchestration & Infra**: Kubernetes YAML, Terraform, Ansible, etc.- **Application Servers**: Tomcat, Jetty, etc. (Note: Tomcat is NOT a containerization tool)- **CI/CD Configs**: GitHub Actions, Jenkinsfile, Azure DevOps YAMLs, etc.
Example:
Maven (Found in pom.xml) – Build and dependency management tool
Tomcat (Referenced in dependencies) – Servlet container used to deploy WARs
Docker (Found in root/Dockerfile) – Containerization of services
Kubernetes (Found in deploy/k8s.yaml) – Deployment management

---
## 5. Recommended CI/CD StagesBased on the above findings, suggest the exact stages required for an automated CI/CD pipeline.
Rules:- Only suggest a stage if it is **backed by actual repo files/configs**- If `<packaging>war</packaging>` is used and Tomcat is detected → include Deploy stage- If Dockerfile is found → include Docker Build & Push- If Kubernetes YAMLs exist → include K8s Deploy stage- If parent POM handles all builds → do Build once, not per module- If only JARs are created and no infra exists → skip Deploy stage
 Format:
Recommended CI/CD Stages:
1. Stage: Build  Tool: Maven 

2. Stage: Test  Tool: JUnit 

3. Stage: Deploy  Tool: Tomcat 


Only include stages and tools if they are fully supported by project structure.
---
Also give any suggested instructions if needed.
Now analyze carefully and return the output in the above format.
Project Files:{file_texts}"""
    response = model.generate_content(prompt)
    return response.text

# ====== STEP 4: Generate CI/CD Pipeline Specification ======
def generate_pipeline_with_llm(detected_info, repo_url, user_additions):
    prompt = f"""
---
You are a DevOps automation expert.Generate a technology-agnostic CI/CD pipeline specification JSON from the following detected project information.

---
Input:
Repository: {repo_url}

Detected Info:

{detected_info}

User Custom Instructions (if any): {user_additions or "None"}


---
 Objective:
Generate a well-structured specification file in the following format:
"{{ "pipeline": {{ "stages": [ {{ "name": "StageName", "tasks": [ {{ "name": "Task Name", "task_type": "task_type_enum", // Task-specific config fields }} ] }} ] }}}}"

---
 Rules to Follow:
1. Repository Handling:
Include a Checkout stage with git task_type using the repo URL if version control is detected.
Use depth: 1 for shallow clone if full history is not required.


2. Build Stage:
If a parent POM exists and the modules are Maven-based with defined dependencies, only one mvn clean install command is enough from the root.
Use task_type "shell" and script mvn clean install.


3. Test Stage:
Only include if tests are configured or mentioned in the detected info.


4. Artifact Stage:
Include an artifact publish task if .jar or .war outputs are detected. Use "artifact" as task_type.
Mention file paths like NotificationService/target/*.jar or OrderService/target/*.war.


5. Deploy Stage:
If WAR file and Tomcat is detected, add a Deploy stage with task_type: "tomcat".
Use a config structure like:
 {{ "tomcat": {{ "url": "http://localhost:8081", "username": "${{TOMCAT_USERNAME}}", "password": "${{TOMCAT_PASSWORD}}", "war_file": "OrderService/target/OrderService.war", "context_path": "/", "update": true }}}} 


6. Skip Irrelevant Stages:
Do not add Docker, Kubernetes, Security Scan, etc., if not found in the detected_info or not requested by user.


7. Task Type Enums:
"git": for checkout tasks
"shell": for script-based build/test
"artifact": for publishing artifacts
"tomcat": for WAR deployments


8. Microservices and Build Order:
Respect detected module build order.
Clearly indicate if the task builds or uses a specific module.
No need to repeat individual module builds if parent build covers it.


9. Do Not Infer Tools:
The specification must remain agnostic to the CI/CD tool. No syntax of Jenkins, Azure, GitHub Actions, etc.


10. User Instructions:
Respect and integrate user’s custom instructions only if they are meaningful and relevant to the detected project.




---
 Output Format:
A single, valid, and complete JSON specification that describes the required CI/CD flow clearly and accurately, including:
Stage names
Tasks per stage
Task types and configurations
File paths based on module structure

Do not include explanations or markdown — return only raw JSON.

---
"""
    response = model.generate_content(prompt)
    return response.text

# ====== STEP 5: Generate CI/CD Pipeline ======
def generate_pipeline(detected_info, repo_url, user_additions, ci_cd_tool, specification, os):
    prompt = f"""
---
You are an expert CI/CD pipeline generator.Your task is to convert the following technology-agnostic CI/CD specification JSON into a complete and production-ready CI/CD pipeline code for the CI/CD tool selected by the user.
The generated pipeline code must be:
Logically and syntactically correct for the selected tool
Secure (avoid hardcoded credentials, use env vars or secret references)
Efficient (avoid redundant stages, reuse build outputs)
Complete (include only relevant stages and tasks)
Customizable (highlight where user needs to configure secrets, paths, agents, etc.)


---

Generate production-ready CI/CD pipeline code for the specified tool based on the following inputs:

Inputs Provided:
1. Repository URL: {repo_url}

2. Detected Project Information: {detected_info}

3. User Custom Instructions: {user_additions or "None"}

4. Target CI/CD Tool: {ci_cd_tool} 

5. Pipeline Specification: {specification}

6. Operating System: {os}

---

Requirements:

1. Code Quality:

- Must be production-grade quality
- Follow best practices for the specified CI/CD tool
- Include proper error handling
- Include necessary logging
- Follow security best practices (no hardcoded credentials)

---
2. Tool-Specific Rules and Guidelines
 
Common Rules (All Tools)

1. Use the exact stages and tasks from the specification.

2. Do not infer tools or steps not explicitly requested or mentioned.

3. Integrate repo_url only in the checkout step using the proper method for the CI/CD tool.

4. Use secure references for sensitive values (e.g., credentials, secrets).

5. Follow the correct build order (from detected_info) and avoid rebuilding modules already covered by a parent build.


---
Tool-Specific Instructions

For jenkins (Declarative Pipeline)
- Generate a declarative Jenkinsfile
- Use pipeline syntax (declarative, not scripted).
- Define agent any or a specific label if detected_info contains agent preference.
- Organize stages to match the specification
- Use checkout([$class: 'GitSCM', ...]) or git step for repo checkout.
- Use sh 'mvn clean install' for build shell tasks.
- For artifact, use archiveArtifacts artifacts: '**/target/*.jar' (or as per specification).
- For tomcat, create a shell task that uses curl or deploy CLI to upload the WAR (and mention env var placeholders for credentials).
- Use environment section to define secret variables.
- Include post-build actions for cleanup/notifications
- Use parallel stages where applicable for performance
- Use shared libraries if complex logic is needed
- If the OS [input]{os}[/input] is Windows, for any shellscript, please use bat instead of sh.
- If the OS  [input]{os}[/input] is Windows, then show only windows compatable code, no need to show code for unix
- If the OS  [input]{os}[/input] is Windows,Instead of using £ before environment variables, use %.Remove $ sign
- Example for Deploy to Tomcat Stage:
          stage('Deploy') {{
            steps {{
                withCredentials([usernamePassword(credentialsId: 'tomcat-credentials', passwordVariable: 'tomcatPassword', usernameVariable: 'tomcatUsername')]) {{ // Replace 'tomcat-credentials' with your Tomcat credentials ID
                    bat '''curl -u %tomcatUsername%:%tomcatPassword% -T OrderService/target/OrderService.war "http://localhost:8081/manager/text/deploy?path=/OrderService&update=true"'''
                }}
            }}
        }}


For azure (Azure DevOps YAML)
- Use a valid Azure DevOps YAML format.
- Use appropriate agent pool (ubuntu-latest/windows-latest)
- Implement stages as specified
- Use variables and variable groups for configuration
- Each stage should have jobs, each job must include proper steps.
- Use checkout: self for Git.
- Use script: mvn clean install inside bash or powershell step for build.
- Use publish task for artifacts like .jar or .war.
- Add appropriate conditions for stage/task execution
- Use relevant script for WAR deploy to Tomcat if applicable.
- Use variables for secrets, and mention that users should add them in Azure Pipelines Library or Pipeline UI.

For aws (AWS CodePipeline)

- Generate CodePipeline JSON or YAML definition.
- Include all required stages (Source, Build, etc.)
- Use CodeBuild for build/test stages
- Implement proper IAM permissions
- Include artifact passing between stages- Use parameter store for secrets
- Add CloudWatch alarms for failures
- Include manual approval steps if needed
- Define Source, Build, Test (optional), Deploy stages.
- Use CodeCommit or GitHub integration in Source with repo_url.
- Use CodeBuild for shell build tasks, define buildspec.yml commands accordingly.
- Use S3 for artifact storage.
- For WAR deployment to Tomcat on EC2, use a custom deploy stage (use S3 + SSH + script).
- Mention use of AWS Secrets Manager or SSM for credentials.

---
3. Stage Implementation:

- Exactly follow the stages and tasks from the specification
- Convert each specification task to appropriate tool 
- Maintain the same order and dependencies
- Include only what's specified - no extra stages

---
4. Security Requirements:

- Never hardcode credentials
- Use the CI/CD tool's secret management
- Apply principle of least privilege
- Scan for vulnerabilities if security tools are specified

---
5. Error Handling:

- Include proper failure notifications
- Implement retry logic where appropriate
- Add timeout handling
- Include cleanup on 

---

6. Documentation:
- Include brief comments explaining each stage
- Add requirements/pre-requisites as comments
- Note any assumptions made

---

Output Format:

- Only output the complete pipeline code file
- No explanations or markdown
- Pure executable code for the specified tool
- Return the complete CI/CD pipeline code only in the format valid for the selected tool.

---
Avoid the Following
Do not add Docker, Kubernetes, or security scan unless explicitly mentioned in user_additions or detected_info.
Do not hardcode usernames, passwords, or URLs — always use variables.
Do not infer CI/CD features (e.g., code coverage, test reports) unless present in inputs.


---
# Setup & User Instructions:

Where you include:
Any required environment variables (e.g., TOMCAT_USERNAME, ACR_PASSWORD)
Where to store secrets (Azure Library, Jenkins Credentials, AWS Secrets Manager)
Agent setup instructions if needed (e.g., EC2 with Java & Tomcat)
Any file that must be added in repo (like buildspec.yml for AWS)
Any pre-requisite tools/plugins needed
Infrastructure requirements
Permission requirements
Recommended monitoring setup
Any customization points for different environments
---

Always give instructions required to run the code at the end .
"""
    response = model.generate_content(prompt)
    return response.text

# ====== Optional Cleanup ======
def cleanup(path):
    try:
        shutil.rmtree(path)
    except Exception:
        pass