# runners/refiner_runner.py

from agents.refiner_agent import PipelineRefiner

session_id = "session-001"
user_id = "ci-user"
refiner_instance = None

async def start_refinement_session(initial_code: str) -> str:
    global refiner_instance
    refiner_instance = PipelineRefiner(initial_code)
    generator = await refiner_instance.start_session()

    output = ""
    async for event in generator:
        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    output += part.text + "\n"
    return output.strip()

async def send_feedback(feedback: str) -> str:
    global refiner_instance
    if not refiner_instance:
        return "Refiner session not started. Please call /start-refinement first."

    generator = await refiner_instance.user_feedback(feedback)

    output = ""
    async for event in generator:
        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    output += part.text + "\n"
    return output.strip()
