from agents.assistant_agent import create_assistant_agent
from runners.agent_runner import run_agent

async def run_assistant(code: str, user_input: str) -> str:
    assistant_agent = create_assistant_agent()

    # Format the chat_history for prompt part
    assistant_prompt = (
                    f"Call the function `assistant_tool` to answer the user question based on:\n"
                    f"Code: {code}\n"
                    f"User input: {user_input}"
                    "Return the complete response"
                )

    assistant_response = await run_agent(assistant_agent, assistant_prompt, app_name="assistant")
    return assistant_response
