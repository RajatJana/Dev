import os
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

async def run_agent(
    agent,
    prompt_text: str,
    app_name: str = "generic_llm_app",
    user_id: str = "default_user"
) -> str:
    session_service = InMemorySessionService()
    session_id = "session_" + os.urandom(4).hex()

    await session_service.create_session(
        user_id=user_id,
        session_id=session_id,
        app_name=app_name
    )

    prompt = types.Content(
        role="user",
        parts=[types.Part(text=prompt_text)]
    )

    runner = Runner(agent=agent, session_service=session_service, app_name=app_name)
    generator = runner.run_async(user_id=user_id, session_id=session_id, new_message=prompt)

    final_output = ""
    async for event in generator:
        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, "text") and part.text:
                    final_output += part.text + "\n"
                elif hasattr(part, "function_call"):
                    print("📦 Function call detected")

    return final_output.strip()