from agents.converter_agent import create_pipeline_converter_agent
from runners.agent_runner import run_agent


async def run_conversion(source_tech: str, target_tech: str, pipeline_code: str, input_os: str) -> str:
    converter_agent = create_pipeline_converter_agent()
    
    converter_prompt = (
    f"Call the function `convert_pipeline_tool` to convert this pipeline "
    f"from {source_tech} to {target_tech}:\n\n{pipeline_code}\n\nOS: {input_os}."
    "Return the converted code only."
)
    converted_code = await run_agent(converter_agent, converter_prompt, app_name="pipeline_converter")
    return converted_code

