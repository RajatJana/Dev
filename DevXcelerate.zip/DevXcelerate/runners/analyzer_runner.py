from agents.analyzer_agent import create_analyzer_agent
from runners.agent_runner import run_agent

async def run_analyzer(repo_link: str) -> str:
    analyzer_agent = create_analyzer_agent()

    # Format the chat_history for prompt part
    analyzer_prompt = (
                    f"Call the function `analyzer_tool` to analyze the repo:\n"
                    f"Repo: {repo_link}\n"
                    "Return the complete response"
                )

    
    analyzer_response = await run_agent(analyzer_agent, analyzer_prompt,app_name="analyzer")
    return analyzer_response
