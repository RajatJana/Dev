from agents.modifier_agent import create_modifier_agent
from runners.agent_runner import run_agent

async def run_modifier(code: str, user_input: str) -> str:
    modifier_agent = create_modifier_agent()

    # Format the chat_history for prompt part
    modifier_prompt = (
                    f"Call the function `modifier_tool` to update the code as per user request:\n"
                    f"Code: {code}\n"
                    f"User Change Request: {user_input}"
                    "Return the complete response"
                )

    modifier_response = await run_agent(modifier_agent, modifier_prompt, app_name="modifier")
    return modifier_response
