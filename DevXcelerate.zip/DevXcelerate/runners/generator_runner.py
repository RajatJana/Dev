from agents.generator_agent import create_generator_agent
from runners.agent_runner import run_agent


async def run_generation(detected_info: str, repo_link: str, user_additions: str, ci_cd_tool: str, os: str) -> str:
    generator_agent = create_generator_agent()
    
    generator_prompt = (
    f"Call the function `generate_pipeline_tool` to generate this pipeline from the given data "
    f"Project Details: {detected_info}\n\nPipeline Technology: {ci_cd_tool}\n\n Repo Link: {repo_link}\n\n User Additional Input: {user_additions}\n\nOS: {os}."
    "Return the generated code only."
)
    generated_code = await run_agent(generator_agent, generator_prompt, app_name="pipeline_generator")
    return generated_code

