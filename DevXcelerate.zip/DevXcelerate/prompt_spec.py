pipelinePrompt = """ ### Task
                  Convert an User Input into a pipeline specification using which DevOps pipeline code can be written in any technology.
                  
            """

pipelinePrompt_TRAI = """ ### Task
                        Convert User Input into the pipeline specification.
                        
                    Below is an instruction that describes a task. Write a response that appropriately completes the request.
                                        
                    ### Instructions
                        - Extract all step,task,script from the given input file and present them in the structured format output.
                        -For each step/task/script , a stage needs to be created in output json.
                        - Ensure that all step/task/script of the input files are included in the output.
                        - Use docker image only when explicitly mentioned otherwise do not use docker  
                        -For Tomcat deployment,please do using tomact user credentials and url. Don't do the deployment by copying artifacts in webapps folder of tomcat
                        - Repeat this format for all tep/task/script and tasks in the input file. 
                        - If the input file includes additional steps ensure they are captured accurately in the output. 
                        - Do not omit any step that present in input file.Do not miss any steps.
                        - Always give tomcat url as localhost by default and port 8081.
                        - Add &update=true where required at the end of tomcat deployment.
                        - Maintain the correct sequence of tasks as given in the input.
                        - Do not include any extra stage if it is not mentioned by the user.
                        -If a particular stage/task/script is not present in input file, then it will not be present in the output.
                           ### Additional Enhancements:
                        - If a **Git Repository Link** is provided, ensure that the project is checked out from the given repository URL.
                        - If applicable, include **server configurations** such as port numbers or environment variables in the pipeline specification.
                        - If any **tool versions** (e.g., Java version, Maven version) are provided, ensure they are referenced correctly in the output.
                        - Ensure the pipeline specification maintains the same **build and deployment logic**.
                        - If multiple stages are present, combine them sequentially into a single specification file.
                        - If the build_order contains a module that is a parent of other modules listed in the dependency_map (i.e., other modules are declared as its dependencies but it doesn't declare dependencies on them within the project), assume this is the root/parent module of a multi-module Maven project. In such cases, the build command should be mvn clean install executed once in the directory of this identified root/parent module. Do not generate separate mvn clean install commands for its child modules.
                        - * Generic Multi-Module Goal Execution:
                              * Instruction: "For multi-module Maven projects, subsequent pipeline stages like test, package, verify, deploy, scan (e.g., SonarQube analysis), or any other standard Maven goal should also be executed once from the root/parent module's directory. Maven will automatically apply these goals to all relevant child modules in the correct build order."
                              * Reason: This is the overarching rule for almost all Maven operations in a multi-module setup.
                          * Specific for Test Stage:
                              * Instruction: "For the test stage, use mvn test in the identified root/parent module's directory. Do not run mvn test individually for each microservice."
                              * Reason: Explicitly addresses the test stage.
                              Include test stage only when it is given by user as stage and tool. 
                          * Specific for SonarQube/Scan Stage:
                              * Instruction: "For the static code analysis or scan stage (e.g., using SonarQube), use mvn sonar:sonar (or the appropriate SonarQube Maven goal) executed from the identified root/parent module's directory. This single command will initiate analysis for all submodules."
                              * Reason: Addresses SonarQube specifically, as it's a common concern.

                    
                ###output
                         The output should:
                        - Have specification of pipeline code in json structured format
                        - Use docker image only when explicitly mentioned otherwise do not use docker  
                        - Ensure the code specification replicates all stages from the input pipeline.
                        - Maintain the same build and deployment logic.
                        - If there are multiple stages present, Join them sequentially as the whole output should be a single specification file.
                    """
yamlPrompt_TRAI = """ ### Task
                        You are a CI/CD pipeline generator. Convert the given JSON specification into a valid YAML pipeline file. .
                        
                    Below is an instruction that describes a task. Write a response that appropriately completes the request.
                                        
                    ### Instructions
                        - Every stage mentioned in the JSON specification must be clearly represented as a stage in the output YAML. No stage should be omitted.
                        - If a **Git Repository Link** is provided, ensure that the project is checked out from the given repository URL.
                        - If applicable, include **server configurations** such as port numbers or environment variables in the pipeline specification.
                        - If any **tool versions** (e.g., Java version, Maven version) are provided, ensure they are referenced correctly in the output.
                        - Ensure the Azure pipeline maintains the same **build and deployment logic**.
                        

                    
                ###output
                         The output should:
                        - A fully-formed, platform-compatible YAML pipeline file adhering to the structure and logic of the JSON specification.
                    """




stages_TRAI ="""
                    Given the following user description, identify and extract only the relevant **pipeline stage(s) and corresponding tool**.  
                        - If the description contains **one stage**, return only that **single stage along with tool** without any additional steps.  
                        - If the description contains **multiple stages**, return all of them **in sequential order** based on logical flow.  
                        - Ensure the extracted stages **strictly match** what is provided in the user description—do not infer or add steps. 
                        - Different stages will be displayed in new line

                  
                    Output Format:  
                        - List **each stage on a new line**.  
                        - If there is only **one stage**, output **just that stage**, without additional descriptions.  
                        - Do **not** add speculative steps beyond what the user has explicitly mentioned.  

                    """
