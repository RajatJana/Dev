﻿from typing import Generator


import os
import Utility as util

class DevOpsChatbot:
    def __init__(self):
        #self.model = self._load_model()
        self.model=util.load_model("gemini-2.0-flash")
        self.system_prompt = """<<SYS>>
You are a helpful DevOps expert assistant. Answer questions about:
- CI/CD pipelines (Jenkins, GitHub Actions, Azure DevOps)
- Cloud platforms (AWS, Azure, GCP)
- Infrastructure as Code (Terraform, Ansible)
- Containerization (Docker, Kubernetes)
- Monitoring and logging
Provide concise, accurate answers with examples when possible.
<</SYS>>"""

    

    def generate_response(self, user_input: str) -> Generator[str, None, None]:
        """Stream generated response"""
        prompt = f"[INST]{self.system_prompt}\n{user_input}[/INST]"
        
        try:
            response = self.model(
                prompt,
                max_tokens=512,
                temperature=0.7,
                top_p=0.9,
                stream=True
            )
        
            if isinstance(response, str):
                yield response
            else:
                for chunk in response:
                    if isinstance(chunk, dict):
                        yield chunk.get("choice", [{}])[0].get("text","")
                    elif isinstance(chunk, str):
                        yield chunk
                    else:
                        yield str(chunk)
        except Exception as e:
            yield f"Error: {e}"

# Singleton instance
chatbot_instance = DevOpsChatbot()