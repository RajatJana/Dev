import yaml
import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModel
from langchain_core.prompts import PromptTemplate
from langchain.schema.output_parser import StrOutputParser
from langchain_core.prompts import FewShotPromptTemplate
import torch
import Utility as util
import prompt_pipeline_spec as PromptPipeline

#Function to escape braces in JSON string
def escape_braces(json_string):
    return json_string.replace("{","{{").replace("}","}}")

with open ('C:/Users/RajatJana/Desktop/DevXcelerate/Examples/S2J_Examples.json','r') as f:
  few_shot_examples = json.load(f)
# Initialize the tokenizer and model for embeddings
tokenizer= AutoTokenizer.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
# Load pre-trained model for embeddings
model =  AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")

# Create embeddings for few-shot examples
example_embeddings = [util.get_embeddings(escape_braces(example["input_example"])) for example in few_shot_examples]

#Create and Populate Faiss Index
dimension = example_embeddings[0].shape[0]
index = faiss.IndexFlatL2(dimension)
embedding_matrix = np.array(example_embeddings).reshape(-1,dimension)
index.add(embedding_matrix)

# Function to perform semantic search
def query_faiss_index(input_text, model, index, few_shot_examples, k=2):
    input_embedding = util.get_embeddings(input_text)
    distances, indices = index.search(np.array([input_embedding]), k)
    relevant_examples = [few_shot_examples[i] for i in indices[0]]
    return relevant_examples

#Function to extract stages from the pipeline specification
def extract_stages(pipeline_spec):
    stages=[]
    if (isinstance(pipeline_spec,list)):
      for item in pipeline_spec:
        if isinstance(item,dict) and "stages" in item:
            stages.extend(item["stages"])
  
    stages_str = json.dumps(stages,indent=4)
    print("extract stages ",stages_str)
    return stages_str
# Function to create the chain using FewShotTemplate 

def create_chain(relevant_examples,input_text,stages,os):
    formatted_examples = [
    {
        "input_example":escape_braces(example["input_example"]),
        "output_example":escape_braces(example["output_example"]),
        "output_docs":(example["output_docs"] )
    } for example in relevant_examples 
    ]
    
    #Define the FewShotTemplate using the retrieved examples
    example_prompt=PromptTemplate(template="""input_example:{input_example}\n output_example:{output_example} \n output_docs:{output_docs}""",input_variables=["input_example","stages","os"])
    template= FewShotPromptTemplate(
        examples=formatted_examples,
        example_prompt=example_prompt,
        prefix=PromptPipeline.codePrompt_TRAI,
        suffix="input_example:{input_example}\n output_example\n output_docs:",
        input_variables=["input_example","stages","os"]
    )  
        # Define the FewShotTemplate using the retrieved examples
   
    llm=util.load_model("gemini-2.0-flash")
    # Define the chain function
    def chain(input_text,stages,os):
        escaped_input_text = escape_braces(input_text)
        escaped_stages_str = escape_braces(stages)
        formatted_input = template.format(input_example=escaped_input_text,stages=escaped_stages_str,os=os)
        return llm.invoke(formatted_input).content
        
    return chain


# Function to convert pipeline specification to Jenkins pipeline
def convert_specification_to_jenkins(pipeline_specification,os):
    print("Operating System ", os)
    # Extract stages from the pipeline
    stages= extract_stages(pipeline_specification)
    input_text = json.dumps(pipeline_specification,indent=4)
    print("input_text ",input_text)
    # Perform semantic search to find relevant examples
    relevant_examples = query_faiss_index(input_text, model, index, few_shot_examples)
    chain = create_chain(relevant_examples,input_text,stages,os)
    jenkins_pipeline = chain(input_text,stages,os)
    return jenkins_pipeline




