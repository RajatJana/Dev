from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.modifier_agent import create_modifier_agent
from runners.modifier_runner import run_modifier
router = APIRouter()

# ✅ Request model
class ModifierRequest(BaseModel):
    code: str
    user_input: str

# ✅ Response model
class ModifierResponse(BaseModel):
    output: str

# 🔌 API endpoint
@router.post("/request-change", response_model=ModifierResponse)
async def connect_to_Modifier(request: ModifierRequest):
    try:
        result = await run_modifier(request.code, request.user_input)
        return ModifierResponse(output=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Modifier error: {str(e)}")