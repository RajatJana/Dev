from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.generator_agent import create_generator_agent
from runners.generator_runner import run_generation
from typing import Literal

router = APIRouter()

# ✅ Request model
class PipelineRequest(BaseModel):
    detected_info: str
    repo_link: str
    user_additions: str
    ci_cd_tool: Literal["azure", "jenkins"]
    os: str

# ✅ Response model
class PipelineResponse(BaseModel):
    pipeline: str

# 🔁 Generator Agent Endpoint
@router.post("/generate-pipeline", response_model=PipelineResponse)
async def generate_pipeline(request: PipelineRequest):
    try:
        # Delegate fully to runner; prompt construction handled internally
        result = await run_generation(detected_info=request.detected_info,
            repo_link=request.repo_link,
            user_additions=request.user_additions,
            ci_cd_tool=request.ci_cd_tool,
            os=request.os
        )

        return PipelineResponse(pipeline=result.strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generator agent error: {str(e)}")