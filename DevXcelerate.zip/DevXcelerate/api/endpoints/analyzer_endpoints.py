from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.analyzer_agent import create_analyzer_agent
from runners.analyzer_runner import run_analyzer

router = APIRouter()

# ✅ Request model
class AnalyzerRequest(BaseModel):
    repo_link: str

# ✅ Response model
class AnalyzerResponse(BaseModel):
    result: str

# 🔌 API endpoint
@router.post("/analyze-codebase", response_model=AnalyzerResponse)
async def analyze_codebase(request: AnalyzerRequest):
    try:
        result = await run_analyzer(request.repo_link)
        return AnalyzerResponse(result=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analyzer error: {str(e)}")