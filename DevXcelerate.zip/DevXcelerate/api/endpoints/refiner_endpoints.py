from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.refiner_agent import PipelineRefiner

router = APIRouter()

refiner_instance = None  # Global instance

# Request Models
class RefinementRequest(BaseModel):
    pipeline_code: str

class FeedbackRequest(BaseModel):
    feedback: str

# Response Model
class RefinementSplitResponse(BaseModel):
    refiner: str
    devops: str

@router.post("/start-refinement", response_model=RefinementSplitResponse)
async def start_refinement(request: RefinementRequest):
    global refiner_instance
    try:
        refiner_instance = PipelineRefiner(request.pipeline_code)
        result = await refiner_instance.start_session()  # ✅ returns dict with keys
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Refiner error: {str(e)}")

@router.post("/send-feedback", response_model=RefinementSplitResponse)
async def send_feedback(request: FeedbackRequest):
    global refiner_instance
    if refiner_instance is None:
        raise HTTPException(status_code=400, detail="Refiner session not started.")
    try:
        result = await refiner_instance.user_feedback(request.feedback)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Refiner error: {str(e)}")
