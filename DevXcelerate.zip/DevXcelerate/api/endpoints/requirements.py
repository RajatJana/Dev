from fastapi import APIRouter
from fastapi import FastAPI
from api.endpoints.converter_endpoints import router as convert_router
from api.endpoints.assistant_endpoints import router as assistant_router
from api.endpoints.generator_endpoints import router as generator_router
from api.endpoints.analyzer_endpoints import router as analyzer_router
from api.endpoints.modifier_endpoints import router as modifier_router
from api.endpoints.refiner_endpoints import router as refiner_router


router = APIRouter()
router.include_router(convert_router)
router.include_router(assistant_router)
router.include_router(generator_router)
router.include_router(analyzer_router)
router.include_router(modifier_router)
router.include_router(refiner_router)