from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.assistant_agent import create_assistant_agent
from runners.assistant_runner import run_assistant
router = APIRouter()

# ✅ Request model
class AssistantRequest(BaseModel):
    code: str
    user_input: str

# ✅ Response model
class AssistantResponse(BaseModel):
    output: str

# 🔌 API endpoint
@router.post("/connect-assistant", response_model=AssistantResponse)
async def connect_to_assistant(request: AssistantRequest):
    try:
        result = await run_assistant(request.code, request.user_input)
        return AssistantResponse(output=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Assistant error: {str(e)}")