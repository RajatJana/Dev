from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Literal
import asyncio
from runners.converter_runner import run_conversion

router = APIRouter()

# ✅ Request schema
class ConversionRequest(BaseModel):
    source_tech: Literal["azure", "jenkins"]
    target_tech: Literal["azure", "jenkins"]
    pipeline_code: str
    input_os: Literal["linux", "windows", "mac"]

# ✅ Response schema
class ConversionResponse(BaseModel):
    converted_code: str

# 🔁 Conversion endpoint
@router.post("/convert-pipeline", response_model=ConversionResponse)
async def convert_pipeline(request: ConversionRequest):
    if request.source_tech == request.target_tech:
        raise HTTPException(status_code=400, detail="Source and target technologies must be different.")

    try:
        converted_code = await run_conversion(
            source_tech=request.source_tech,
            target_tech=request.target_tech,
            pipeline_code=request.pipeline_code,
            input_os=request.input_os
        )
        return ConversionResponse(converted_code=converted_code)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Conversion failed: {str(e)}")