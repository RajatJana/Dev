import streamlit as st
import re
from streamlitapp.ExpertApp import show as expert_show

def show():
    if 'pipeline_code' not in st.session_state:
        st.session_state.pipeline_code = None
    if 'refine_chat' not in st.session_state:
        st.session_state.refine_chat = False

    # Title
    st.markdown("""
        <h1 style="color:#FE0175;text-align:center;">🛠️ CI/CD Pipeline Refiner</h1>
        <p style="text-align:center;">Refine DevOps pipelines with AI agents + your feedback</p>
    """, unsafe_allow_html=True)

    if st.session_state.pipeline_code is None:
        file = st.file_uploader("**Choose a pipeline file**", type=None)
        if file is not None:
            st.session_state.pipeline_code = file.read().decode("utf-8") 
    if st.session_state.pipeline_code:  
        st.write("#### File Preview:")  
        st.code(st.session_state.pipeline_code, language="yaml")

        cols = st.columns([1, 1, 1, 1, 1])
        with cols[0]:
            if st.button("🧠 Refine", use_container_width=True):
                st.session_state.refine_chat = True
        with cols[4]:
            st.download_button(  
                    label="💾 Download Pipeline",  
                    data=st.session_state.pipeline_code,  
                    file_name="updated.txt",  
                    mime="text/plain",
                    use_container_width=True 
                )   

        if st.session_state.refine_chat:
            expert_show()