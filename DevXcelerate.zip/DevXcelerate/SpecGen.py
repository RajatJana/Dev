import os
import requests
from docx2txt import process
from langchain_community.llms import CTransformers
import textwrap
import json
from docx import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
#from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_huggingface.embeddings import HuggingFaceEmbeddings
import streamlit as st
import re
import json
import Utility as util
from transformers import AutoTokenizer, AutoModel
from langchain_ollama.llms import OllamaLLM

# Validate JSON
def validate_json(json_string):
    try:
        json.loads(json_string)
        return True
    except json.JSONDecodeError:
        return False
    
# Model path configuration

EMB_MODEL_KWARGS = {'device': 'cpu'}
EMB_ALL_MINILM_L6_V2_MODEL_ID = "sentence-transformers/all-MiniLM-L6-v2"
VDB_PATH = "./VDB_Chroma"
llm=util.load_model("gemini-2.0-flash")
#llm= OllamaLLM(model="llama3.2:3b",base_url="http://localhost:11434/")
 

def getVectorStore(doc_content, file_name):

    emb_all_MiniLM_L6_v2 = HuggingFaceEmbeddings(model_name=EMB_ALL_MINILM_L6_V2_MODEL_ID, model_kwargs=EMB_MODEL_KWARGS)
    
# Initialize embedding model
    
   # emb_all_MiniLM_L6_v2 = AutoModel.from_pretrained("sentence-transformers/all-MiniLM-L6-v2")
    file_name = file_name.rsplit(".",1)[0]
    

    if not (os.path.exists(VDB_PATH+"/"+file_name)):
        os.makedirs(VDB_PATH+"/"+file_name, exist_ok=True)

    if  (os.path.exists(VDB_PATH+"/"+file_name+"/chroma.sqlite3")): #chroma.sqlite3
        print("\n\n\nVDB ALREADY EXISTS\n\n\n")
        vectorstore = Chroma(persist_directory= VDB_PATH+"/"+file_name, embedding_function=emb_all_MiniLM_L6_v2, collection_name="cicd")
    else:
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=8000, chunk_overlap=400, separators=["\n \n","\n\n",".\n","\n",".",]) #["\n \n","\n\n",".\n","\n",".",]
        doc_text = text_splitter.create_documents([doc_content]) 
        print(doc_text)
        vectorstore = Chroma.from_documents(doc_text, emb_all_MiniLM_L6_v2, persist_directory=VDB_PATH+"/"+file_name, collection_name="cicd")
    return vectorstore

 

def llm_function(query):
   
    print(query)
    
    llm_config = {'max_new_tokens': 2048, 'temperature' : 0.2, 'context_length':4000, 'threads': 8}

    prompt = """
      <|begin_of_text|><|start_header_id|>system<|end_header_id|>
     Extract and generate a comprehensive JSON specification file based on the provided Technical Design Document (TDD). Ensure the JSON output is structured according to the sections below, strictly adhering to the required format.

**Instructions for Extraction:**
1. Carefully parse and extract relevant details from the TDD.
2. Ensure each section is populated with accurate data.
3. Maintain proper JSON formatting for validity.

**JSON Specification Structure:**
- **Metadata:** Extract title, author, and date.
- **Technologies:** Identify unique technologies, frameworks, and libraries.
- **Tools:** List all unique tools, software, and platforms required.
- **Implementation Steps:** Organize sequential steps into stages.
  - Each stage should have a `"stage"` key (string) and an optional `"steps"` key (list of task objects).
- **Services:** Define all services, APIs, and integrations with details.
  - Include authentication methods and API endpoints if applicable.
- **System Context:** Describe external interfaces, information flow rates, concurrency, and security considerations.
- **System Design:** Provide system architecture details, including methods, technologies, standards, and architectural patterns.
- **Outstanding Issues:** List unresolved design issues with descriptions, impact, and solutions.
- **Component Description:** Provide software component details with dependencies, interfaces, resources, and processing details.
- **Software Requirements Traceability Matrix:** If available, represent mapping between requirements and components.
- **Documentation & Programming Standards:** List relevant standards with descriptions and implementation details.

**Example JSON Structure:**
```json
{
    "stages": [
        {
            "stage": "Gradle Build",
            "steps": [
                {
                    "task": "Gradle",
                    "inputs": {
                        "gradleFile": "build.gradle",
                        "goals": "clean build"
                    },
                    "displayName": "GradleBuild"
                }
            ]
        }
    ]
}
    
    return json_spec

    <|eot_id|><|start_header_id|>user<|end_header_id|>
    Here is the Technology Design document: \'\'\'{query}\'\'\'.
    Please generate a JSON specification file with the extracted details, strictly adhering to the structure and data types specified above. Ensure that the JSON is valid and complete. Extract as much detail as possible for each section mentioned.
    <|eot_id|><|start_header_id|>assistant<|end_header_id|>"""                 
    
    prompt = prompt.replace("{query}", str(query))
        
        
    llm_response = llm.invoke(prompt).content
    print(llm_response)    
    return llm_response

def process_document(doc_content, file_name):
    print("Entered PD: content:",doc_content)
    
    vdb_obj = getVectorStore(doc_content,file_name)
    retriever = vdb_obj.as_retriever(search_type="mmr",search_kwargs={"k":10})
    vdb_res = retriever.invoke("Read and extract relevant details from Technology design document")
    print(vdb_res)
    
    llm_response = llm_function(vdb_res)

    if llm_response :
        pattern = r"```(.*?)```"
        match = re.search(pattern, llm_response, re.DOTALL)

        if match:
            json_data = match.group(1)
            start_point = json_data.find("{")
            end_point = json_data.rfind("}")
            json_data = json_data[start_point:end_point+1]
            try:
                json.loads(json_data)
                print(json_data)
                with open('json_specification.json', 'w') as f:
                    json.dump(json.loads(json_data), f, indent=4)
                print("JSON specification file has been generated and saved as 'json_specification.json'.")
                return json_data
            except json.JSONDecodeError:
                print("Invalid JSON data")
        else:
            print("No match found")
    else:
        print("Invalid JSON generated.")
        return None
    return llm_response

def spec_gen(doc_content, file_name):
   
    response = process_document(doc_content, file_name)
    print(response)
    print("JSON specification file has been generated and saved as 'json_specification.json'.")
    return response # Return the response instead of just printing it
