﻿import json
import faiss
import numpy as np
import torch
import os
import Utility as util
import os
import json
import shutil
import tempfile
import networkx as nx
import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple, Optional
from git import Repo, GitCommandError
from rich import print
from rich.table import Table
from pyvis.network import Network
import spacy

# Default mappings for stages and tools
DEFAULT_STAGE_TOOLS = {
    "build": ["maven", "gradle", "npm", "pip", "docker"],
    "test": ["junit", "testng", "jest", "pytest"],
    "deploy": ["tomcat", "kubernetes", "jenkins"],
    "scan": ["sonarqube", "sonar qube", "nexus", "sonar"],
    "monitor": ["prometheus", "grafana"],
    "version": ["git"],
    "push": ["docker"],
    "pull": ["docker"],
    "run": ["docker"]
}

DEFAULT_TOOL_STAGES = {
    tool: stage for stage, tools in DEFAULT_STAGE_TOOLS.items() for tool in tools
}

def clone_repo(repo_url: str) -> str:
    temp_dir = tempfile.mkdtemp()
    try:
        print(f"[cyan]Cloning repository from {repo_url}...[/cyan]")
        Repo.clone_from(repo_url, temp_dir)
        print(f"[green]Repository cloned to {temp_dir}[/green]")
        return temp_dir
    except GitCommandError as e:
        print(f"[red]Git clone failed: {e}[/red]")
        shutil.rmtree(temp_dir)
        raise

def detect_technologies(repo_path: str) -> Dict[str, List[str]]:
    techs = {"Java+Maven": [], "Node.js+npm": [], "Python+pip": []}
    for root, dirs, files in os.walk(repo_path):
        if "pom.xml" in files:
            techs["Java+Maven"].append(root)
        elif "package.json" in files:
            techs["Node.js+npm"].append(root)
        elif "requirements.txt" in files or any(f.endswith(".py") for f in files):
            techs["Python+pip"].append(root)
    return {k: v for k, v in techs.items() if v}

def extract_java_dependencies(services: List[str]) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    service_names = {}
    dependencies = {}

    for path in services:
        try:
            tree = ET.parse(os.path.join(path, "pom.xml"))
            root = tree.getroot()
            ns = {'m': 'http://maven.apache.org/POM/4.0.0'}

            artifact = root.find("m:artifactId", ns)
            if artifact is None:
                continue
            service_name = artifact.text
            service_names[path] = service_name
            dependencies[service_name] = []

            for dep in root.findall(".//m:dependencies/m:dependency", ns):
                group_id = dep.find("m:groupId", ns)
                artifact_id = dep.find("m:artifactId", ns)
                if group_id is not None and artifact_id is not None:
                    dependencies[service_name].append(artifact_id.text)
        except Exception as e:
            print(f"[red]Failed to parse pom.xml in {path}: {e}[/red]")

    # Filter to only internal dependencies
    internal = set(dependencies.keys())
    filtered = {svc: [d for d in deps if d in internal] for svc, deps in dependencies.items()}
    return filtered, service_names

def build_dependency_graph(dep_map: Dict[str, List[str]]) -> nx.DiGraph:
    graph = nx.DiGraph()
    for svc, deps in dep_map.items():
        graph.add_node(svc)
        for dep in deps:
            graph.add_edge(dep, svc)  # Edge from dependency to dependent
    return graph

def sort_microservices(graph: nx.DiGraph) -> List[str]:
    try:
        return list(nx.topological_sort(graph))
    except nx.NetworkXUnfeasible:
        cycles = list(nx.simple_cycles(graph))
        print(f"[red]Cyclic dependencies detected: {cycles}[/red]")
        raise

def visualize_with_pyviz(graph: nx.DiGraph, filename: str = "dependency_graph.html"):
    net = Network(height="750px", width="100%", directed=True)
    net.toggle_physics(False)

    for node in graph.nodes():
        net.add_node(node, label=node)

    for source, target in graph.edges():
        net.add_edge(source, target)

    print(f"[cyan]Generating interactive graph: {filename}[/cyan]")
    html_content = net.generate_html()
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    return filename

def extract_phrases(text: str) -> List[str]:
    nlp = spacy.load("en_core_web_sm")
    ignored_verbs = {"generate", "implement"}
    predefined_tools = {"maven", "gradle", "sonarqube", "sonar qube", "tomcat", 
                       "docker", "jenkins", "kubernetes", "acr", "ecr", "git", 
                       "nexus", "jira", "python"}
    ignored_nouns = {"task", "thing", "project", "process", "pipeline", 
                    "application", "code"}
    doc = nlp(text)
    output = []

    for sent in doc.sents:
        for chunk in sent.text.split(','):
            for subchunk in chunk.split('and'):
                subchunk = subchunk.strip()
                if not subchunk:
                    continue

                subdoc = nlp(subchunk)
                verb = None
                tools = []
                nouns = []

                for token in subdoc:
                    if token.pos_ == "VERB" and token.text.lower() not in ignored_verbs:
                        verb = token.lemma_.capitalize()
                        break

                for token in subdoc:
                    if token.text.lower() in predefined_tools:
                        tools.append(token.text)

                for token in subdoc:
                    if token.pos_ in {"NOUN", "PROPN"} and token.text.lower() not in ignored_nouns:
                        nouns.append(token.text)

                if not verb and nouns:
                    verb = nouns.pop(0)

                selected_word = tools if tools else nouns
                if verb or selected_word:
                    output.append(f"{verb} {''.join(selected_word)}" if verb else ''.join(selected_word))

    return output

def process_stage_tool(phrases: List[str], detected_tech: str) -> List[Dict[str, str]]:
    stage_tool_pairs = []
    tech_tools = {
        "Java+Maven": ["maven"],
        "Node.js+npm": ["npm"],
        "Python+pip": ["pip"]
    }
    
    detected_tools = tech_tools.get(detected_tech, [])
    
    for phrase in phrases:
        parts = phrase.split()
        stage = None
        tool = None
        
        # Try to identify stage and tool from the phrase
        for part in parts:
            lower_part = part.lower()
            if lower_part in DEFAULT_TOOL_STAGES:
                tool = lower_part
                stage = DEFAULT_TOOL_STAGES[tool]
            elif lower_part in DEFAULT_STAGE_TOOLS:
                stage = lower_part
        
        # If we found a tool but no stage, get stage from tool
        if tool and not stage:
            stage = DEFAULT_TOOL_STAGES.get(tool)
        
        # If we found a stage but no tool, try to get tool
        if stage and not tool:
            # First try to get from detected tools if it matches the stage
            for dt in detected_tools:
                if DEFAULT_TOOL_STAGES.get(dt) == stage:
                    tool = dt
                    break
            
            # If still no tool, get first default tool for this stage
            if not tool and stage in DEFAULT_STAGE_TOOLS:
                tool = DEFAULT_STAGE_TOOLS[stage][0]
        
        # If we have neither, use first detected tool and its stage
        if not stage and not tool and detected_tools:
            tool = detected_tools[0]
            stage = DEFAULT_TOOL_STAGES.get(tool)
        
        # If we have stage but no tool (and no detected tools), use default for stage
        if stage and not tool:
            if stage in DEFAULT_STAGE_TOOLS and DEFAULT_STAGE_TOOLS[stage]:
                tool = DEFAULT_STAGE_TOOLS[stage][0]
        
        # If we have tool but no stage (and tool not in defaults), use build as default stage
        if tool and not stage:
            stage = "build"
        
        # Capitalize stage for output
        if stage:
            stage = stage.capitalize()
        if tool:
            tool = tool.capitalize()
        
        if stage or tool:
            stage_tool_pairs.append({"stage": stage, "tool": tool})
    
    return stage_tool_pairs

def output_results(techs: Dict[str, List[str]], build_order: List[str], 
                  dep_map: Dict[str, List[str]], stage_tools: List[Dict[str, str]]):
    print("\n[bold cyan]Technologies Detected:[/bold cyan]")
    for tech, services in techs.items():
        print(f"- {tech}: {len(services)} services")

    print("\n[bold green]Build Order (Topologically Sorted):[/bold green]")
    for i, svc in enumerate(build_order, 1):
        print(f"{i}. {svc}")

    print("\n[bold yellow]Dependency Map:[/bold yellow]")
    table = Table(title="Microservice Dependencies")
    table.add_column("Microservice", style="bold")
    table.add_column("Depends On", style="dim")
    for svc, deps in dep_map.items():
        table.add_row(svc, ", ".join(deps) if deps else "None")
    print(table)

    print("\n[bold magenta]Stage and Tool Information:[/bold magenta]")
    stage_table = Table(title="Pipeline Stages")
    stage_table.add_column("Stage", style="bold")
    stage_table.add_column("Tool", style="bold")
    for st in stage_tools:
        stage_table.add_row(st.get("stage", "Unknown"), st.get("tool", "Unknown"))
    print(stage_table)

    # Prepare JSON output
    result = {
        "technologies": list(techs.keys()),
        "build_order": build_order,
        "dependency_map": dep_map,
        "stage_tools": stage_tools
    }

    print("\n[bold]JSON Output:[/bold]")
    print(json.dumps(result, indent=2))
    return result
   


def extract_details(user_input,repo_url):
    
    # Clone repo and detect technologies
    repo_path = clone_repo(repo_url)
    techs = detect_technologies(repo_path)
        
    # Process dependencies if Java+Maven detected
    dep_map = {}
    build_order = []
    detected_tech = ""
        
    if techs:
        detected_tech = next(iter(techs.keys()))  # Get first detected technology
        if "Java+Maven" in techs:
            dep_map, _ = extract_java_dependencies(techs["Java+Maven"])
            graph = build_dependency_graph(dep_map)
            build_order = sort_microservices(graph)
            visualize_with_pyviz(graph)
        
    # Process user input for stages and tools
    phrases = extract_phrases(user_input)
    stage_tools = process_stage_tool(phrases, detected_tech)
        
    # Output all results
    output_results(techs, build_order, dep_map, stage_tools)
    return techs, build_order, dep_map, stage_tools
        








