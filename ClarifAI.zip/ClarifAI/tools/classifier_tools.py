# tools/classifier_tools.py
import logging
from typing import List, Dict
from utils.logger import get_logger
import json

from tools.prompt_utils import extract_clean_json

def classify_requirement_tool(extracted_requirements: List[Dict], run_llm, verbose=False) -> Dict:
    """
    Classify a requirement using Gemini and return its type.
    """

    # Step 1: First set up the logger
    """ tool_logger = get_logger(
        log_to_console=False,
        log_to_file=True,
        level=logging.DEBUG if verbose else logging.INFO
    ) """

    # Step 2: Build the requirements that needs classification
    req_lines = "\n".join([
        f'{req["requirement_id"]}: {req["requirement_text"]}' for req in extracted_requirements
    ])

    # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + req_lines)

    # Step 3: Build the prompt
    prompt = f"""
        You are a senior business analyst.

        Below is a list of software requirements. Classify each requirement into one of the following main categories/types:

        - Functional : These requirements specify what the system must do. They define the core functions, features, and behaviors of the software.

        - Non-Functional : These requirements specify how the system should perform. They describe the quality attributes, constraints, and operational characteristics of the software.

        Also, assign a more specific subcategory from the following list:
        
        Subcategories for Functional Requirements:

        -Business Rules

        -User Interactions

        -Authentication / Authorization
        
        -Data Management

        -System

        -External Integration

        -Reporting 

        -Transaction Handling

        -Compliance      
        
        -(You may also add "Core" as a subcategory for Functional requirements if none of the other subcategories apply) 

        Subcategories for Non-Functional Requirements:        
        
        -Security

        -Performance

        -Usability

        -Reliability 
        
        -Availability

        -Maintainability

        -Monitoring and Logging

        -Scalability

        -Compliance      
        
        Also, Return a confidence score from 0.0 (unsure) to 1.0 (very confident)
        Also, Identify and Return the primary stakeholders relevant to the requirement (e.g., Customer, Compliance Officer, DevOps, Admin, End-user, API Partner, etc.)

        Return a JSON array in this exact format:
        [
            {{
                "requirement_id": "REQ-001",
                "requirement_type": "Functional",
                "sub_category": "Core",
                "confidence_score": 0.92,
                "stakeholders": ["Customer", "Admin"]
            }},
            ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirement:
        ```{req_lines}```
    """.strip()

    # log the prompt
    # tool_logger.debug("[ClassifyRequirementTool] Requirements that need classification:\n" + prompt)

    response = run_llm(prompt)
    # tool_logger.debug("[ClassifyRequirementTool] LLM raw response:\n" + response)

    try:
        # llm_results = json.loads(response)
        llm_results = extract_clean_json(response)
    except Exception as e:
        # tool_logger.error(f"[ClassifyRequirementTool] Failed to parse LLM response: {e}")
        llm_results = []

    # Step 4: map the results back to the requirement id for each requirement
    result_map = {
        r["requirement_id"]: r for r in llm_results
    }

    for req in extracted_requirements:
        req_type = result_map.get(req["requirement_id"], "Unknown")
        req["requirement_type"] = req_type.get("requirement_type", "Unknown")
        req["sub_category"] = req_type.get("sub_category", "Unknown")
        req["confidence_score"] = req_type.get("confidence_score", 0.0)
        req["stakeholders"] = req_type.get("stakeholders", [])

        # tool_logger.info(f"[ClassifyRequirementTool] : {req['requirement_id']}: {req_type}")

    return {"classified_requirements": extracted_requirements}