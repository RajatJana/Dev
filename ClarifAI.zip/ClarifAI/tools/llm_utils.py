# tools/llm_utils.py
import google.generativeai as genai
import os

from utils.logger import get_logger

logger = get_logger()

genai.configure(api_key=os.getenv("GOOGLE_API_KEY",default=""))
LLM_MODEL = "gemini-2.0-flash"

# def call_gemini(prompt: str) -> str:
#     logger.info(f"[call_gemini] Calling llm with model set as {LLM_MODEL}")

#     model = genai.GenerativeModel(LLM_MODEL)
#     response = model.generate_content(prompt)
#     return response.text

def call_gemini(prompt: str, api_key: str = None, model: str = None) -> str:
    logger.info(f"[call_gemini] Calling llm with model set as {model or LLM_MODEL}")

    genai.configure(api_key=api_key or os.getenv("GOOGLE_API_KEY", default="..."))
    model_name = model or LLM_MODEL
    model_obj = genai.GenerativeModel(model_name)
    response = model_obj.generate_content(prompt)
    return response.text