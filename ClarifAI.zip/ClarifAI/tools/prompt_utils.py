import re
import json
from typing import Optional, Dict

def build_json_prompt(task_description: str, input_text: str, json_template: str) -> str:
    """
    Build a prompt that asks the LLM to return raw JSON with strict formatting.
    """
    return f"""
    {task_description}

    Input:
    \"\"\"{input_text}\"\"\"

    Return only the following JSON format:
    {json_template}

    IMPORTANT:
    - Do NOT include triple backticks (```).
    - Do NOT use Markdown.
    - Do NOT add any explanation.
    Return only raw JSON text.
    """.strip()


def extract_clean_json(llm_response: str) -> Optional[Dict]:
    """
    Extract and parse a clean JSON object from an LLM response.
    Removes markdown fences if present.
    """
    # Strip markdown code fences and leading/trailing whitespace
    cleaned = re.sub(r"```(?:json)?", "", llm_response, flags=re.IGNORECASE).strip()

    try:
        return json.loads(cleaned)
    except Exception:
        return None