# streamlit_clarifAI.py
import streamlit as st
from io import StringIO
import logging
import os
from typing import List, Dict

from agents.extractor_agent import ExtractorAgent
from agents.classifier_agent import ClassifierAgent
from agents.validation_agent import ValidationAgent
from agents.user_story_agent import UserStoryAgent
from agents.gherkin_agent import GherkinAgent
from agents.traceability_agent import TraceabilityAgent
from agents.testcase_agent import TestCaseAgent

import tempfile
import os
import pandas as pd
import openpyxl
from io import BytesIO

from utils.logger import get_logger
from utils import jira_utils

from tools.llm_utils import call_gemini
from st_aggrid import AgGrid, GridOptionsBuilder

# --- Page Config ---
st.set_page_config(
    page_title="Requirement Extractor",
    layout="wide"
)

# --- Setup Logging ---
@st.cache_resource
def setup_logger():
    log_stream = StringIO()
    st.session_state["log_stream"] = log_stream
    os.makedirs("logs", exist_ok=True)
    logger = logging.getLogger("ClarifAI")
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        file_handler = logging.FileHandler("logs/ClarifAI.log")
        stream_handler = logging.StreamHandler(log_stream)
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        file_handler.setFormatter(formatter)
        stream_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)
        logger.propagate = False

    return logger, log_stream

logger, log_stream = setup_logger()

# --- Session State Setup ---
if "extracted" not in st.session_state: st.session_state["extracted"] = None
if "classified" not in st.session_state: st.session_state["classified"] = None
if "validated" not in st.session_state: st.session_state["validated"] = None
if "user_stories" not in st.session_state: st.session_state["user_stories"] = None

st.title("ClarifAI - AI Powered Requirement Phase")
st.markdown("Upload a `.docx` BRD file to extract candidate requirements using an agentic AI pipeline.")

# --- Tabs ---
tabs = st.tabs(["Extractor", "Classifier", "Validator", "User Stories", "Gherkin", "Test Cases", "Traceability", "Logs"])

# --- Extractor Tab ---
with tabs[0]:
    st.header("1. Upload BRD (.docx)")
    st.markdown("Upload a `.docx` BRD file to extract candidate requirements using an agentic AI pipeline.")
    uploaded_file = st.file_uploader("Upload BRD document", type=["docx", "pdf"])

    if uploaded_file and st.button("Extract Requirements"):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(uploaded_file.read())
            temp_path = tmp.name
        agent = ExtractorAgent(llm_caller=call_gemini)
        extracted = agent.run(temp_path)
        st.session_state["extracted"] = extracted
        st.success(f"Extracted {len(extracted)} candidate requirements.")
        st.json(extracted)

# --- Classifier Tab ---
with tabs[1]:
    st.header("2. Classify Requirements")
    raw_reqs = st.session_state["extracted"]
    
    if not raw_reqs:
        st.warning("Please Extract requirements first.")
    else:
        # Fix: Convert to structured format if needed
        raw_reqs = st.session_state["extracted"]
        extracted_requirements = []
        for idx, r in enumerate(raw_reqs):
            if isinstance(r, dict):
                extracted_requirements.append(r)
            else:
                extracted_requirements.append({
                    "requirement_id": f"REQ-{idx+1:03d}",
                    "requirement_text": str(r).strip()
                })
        
        min_conf = st.slider("Min confidence", 0.0, 1.0, 0.0, 0.05)

        if st.session_state.get("extracted"):
            with st.spinner("Classifying via LLM..."):            
                agent = ClassifierAgent(llm_caller=call_gemini)
                result = agent.run(extracted_requirements)
                st.session_state["classified"] = result["classified_requirements"]

                for req in st.session_state["classified"]:
                    if req["confidence_score"] < min_conf:
                        continue
                    st.markdown(f"**{req['requirement_id']}** — {req['requirement_type']} ({req['confidence_score']:.2f})")
                    st.markdown(f"> {req['requirement_text']}")
                    st.progress(req["confidence_score"])
                    st.markdown(f"**Stakeholders**: {', '.join(req["stakeholders"]) if req["stakeholders"] else 'N/A'}")
                    st.markdown("---")

# --- Validator Tab ---
with tabs[2]:
    st.header("3. Validate Requirements")

    if st.session_state.get("classified"):
        agent = ValidationAgent(llm_caller=call_gemini)
        result = agent.run({"classified_requirements": st.session_state["classified"]})
        st.session_state["validated"] = result["validated_requirements"]
        st.success(f"Validated {len(result['validated_requirements'])} requirements.")

        for req in result["validated_requirements"]:
            rid = req["requirement_id"]
            st.markdown(f"### Requirement: {rid}")
            st.markdown(f"**Text**: {req['requirement_text']}")
            passed = req["validation"].get("llm_check_passed", False)

            if passed:
                st.markdown(f"✅ **Valid** — _{req['validation'].get('justification', 'No justification provided')}_")
            else:
                st.markdown("❌ **Invalid Requirement**")
                issues = req["validation"].get("issues", [])
                if issues:
                    st.markdown("**Issues:**")
                    for issue in issues:
                        st.markdown(f"- {issue}")
            st.markdown("---")
    else:
        st.warning("Please run the Classification agent first.")

# --- User Story Tab ---
with tabs[3]:
    st.header("4. Generate User Stories")
    if st.session_state["validated"]:
        min_conf = st.slider("Min story confidence", 0.0, 1.0, 0.0, 0.05)
        agent = UserStoryAgent(llm_caller=call_gemini)
        result = agent.run({"validated_requirements": st.session_state["validated"]})
        st.session_state["user_stories"] = result["user_stories"]

        for story in result["user_stories"]:
            if story["confidence_score"] < min_conf:
                continue
            st.markdown(f"**{story['requirement_id']}** — Confidence: `{story['confidence_score']:.2f}`")
            st.markdown(f"> *{story['user_story']}*")
            st.markdown("**Acceptance Criteria:**")
            for ac in story["acceptance_criteria"]:
                st.markdown(f"- {ac}")
            st.progress(story["confidence_score"])
            st.markdown("---")

        # --- Add this block for Jira posting ---
        if st.button("Post User Stories to Jira"):
            result = jira_utils.post_user_stories_to_jira(st.session_state["user_stories"])
            if result:
                st.success("User stories posted to Jira!")
            else:
                st.error("Failed to post user stories to Jira.")

# --- Gherkin Scenario Tab ---
with tabs[4]:
    st.header("5. Generate Gherkin Scenarios")
    if st.session_state.get("user_stories"):
        min_gherkin_conf = st.slider("Minimum confidence", 0.0, 1.0, 0.0, 0.05)
        agent = GherkinAgent(llm_caller=call_gemini)
        result = agent.run({"user_stories": st.session_state["user_stories"]})

        st.session_state["gherkin_scenarios"] = result["gherkin_scenarios"]
        st.success(f"Generated Gherkin for {len(result['gherkin_scenarios'])} requirements.")

        for item in result["gherkin_scenarios"]:
            if item.get("confidence_score", 0.0) < min_gherkin_conf:
                continue
            st.markdown(f"### Feature: {item['feature']} ({item['requirement_id']}) — Confidence: `{item.get('confidence_score', 0.0):.2f}`")
            st.progress(item.get("confidence_score", 0.0))
            for scenario in item.get("scenarios", []):
                st.markdown(f"**Scenario: {scenario['name']}**")
                for step in scenario.get("steps", []):
                    st.markdown(f"- {step}")
            st.markdown("---")
            
            # add a download option for the feature
            feature_text = f"Feature: {item['feature']}\n\n"
            for s in item["scenarios"]:
                feature_text += f"  Scenario: {s['name']}\n"
                for step in s["steps"]:
                    feature_text += f"    {step}\n"
            st.download_button(
                label=f"Download {item['requirement_id']}.feature",
                data=feature_text,
                file_name=f"{item['requirement_id']}.feature",
                mime="text/plain"
            )
    else:
        st.warning("User stories not available. Please run the User Story agent first.")

# --- Test Cases Scenario Tab ---
with tabs[5]:
    st.header("6. Generate Test Cases")
    if st.session_state.get("user_stories"):
        agent = TestCaseAgent(llm_caller=call_gemini)
        result = agent.run({"user_stories": st.session_state["user_stories"]})

        st.session_state["test_cases"] = result["test_cases"]
        st.success(f"Generated {len(result['test_cases'])} Test Cases.")

        for test in result["test_cases"]:
            test_id = test.get("test_id", "")
            title = test.get("title", "")
            precondition = test.get("precondition", "")
            steps = test.get("steps", [])
            expected = test.get("expected_result", "")
            priority = test.get("priority", "Medium")
            tags = test.get("tags", [])

            st.markdown(f"### 🧪 Test Case: {test_id} - ({title})")
            st.markdown(f"**Precondition: {precondition}**")
            st.markdown(f"**Priority: {priority}**")
            st.markdown(f"**Tags: {" ".join(f"@{tag}" for tag in tags)}**")
            for step in steps:
                st.markdown(f"- Step: {step}")
            st.markdown(f"**Expected Result: {expected}**")

            st.markdown("---")

# --- Traceability Tab ---
with tabs[6]:
    st.header("7. Traceability Matrix")
    
    classified = st.session_state.get("classified", [])
    validated = st.session_state.get("validated", [])
    user_stories = st.session_state.get("user_stories", [])
    gherkin = st.session_state.get("gherkin_scenarios", [])

    if any([classified, validated, user_stories, gherkin]):
        agent = TraceabilityAgent()
        result = agent.run({
            "classified": classified,
            "validated": validated,
            "user_stories": user_stories,
            "gherkin_scenarios": gherkin
        })
        trace_df = pd.DataFrame(result["traceability"])
        st.session_state["traceability_matrix"] = trace_df

        st.markdown("### 📋 Interactive Traceability Matrix")

        gb = GridOptionsBuilder.from_dataframe(trace_df)
        gb.configure_default_column(wrapText=True, autoHeight=True, resizable=True, sortable=True, filter=True)
        gb.configure_grid_options(domLayout='normal')
        grid_options = gb.build()

        AgGrid(
            trace_df,
            gridOptions=grid_options,
            height=400,
            fit_columns_on_grid_load=True,
            enable_enterprise_modules=False,
        )

        st.download_button(
            label="Download Traceability Matrix",
            data=trace_df.to_csv(index=False),
            file_name="traceability_matrix.csv",
            mime="text/csv"
        )
    else:
        st.warning("Run previous agents to generate traceability matrix.")

# --- Logs Tab ---
with tabs[7]:
    st.header("Execution Logs")
    auto = st.checkbox("Auto-refresh logs", value=True)
    out = st.empty()
    log_stream = st.session_state.get("log_stream", StringIO())

    if auto:
        import time
        for i in range(3):
            out.text_area("Logs", value=log_stream.getvalue(), height=400, key=f"log_output_auto_{i}", disabled=True)
            time.sleep(1)
    else:
        out.text_area("Logs", value=log_stream.getvalue(), height=400, key="log_output_manual", disabled=True)