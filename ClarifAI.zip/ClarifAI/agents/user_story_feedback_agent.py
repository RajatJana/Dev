from typing import Dict, Callable
import logging

from tools.prompt_utils import extract_clean_json

logger = logging.getLogger(__name__)

class UserStoryFeedbackAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        story = inputs.get("story", {})
        feedback = inputs.get("feedback", "").strip()

        if not story or not feedback:
            logger.warning("Missing story or feedback in input")
            return {"updated_story": story, "error": "Missing story or feedback"}

        # Build prompt
        prompt = f"""
        You are a senior product owner reviewing a user story.

        Here is the current story:
        User Story ID: {story.get("usid")}
        Title: {story.get("title")}
        Role: {story.get("role")}
        Story: {story.get("story")}
        Acceptance Criteria:
        {chr(10).join(f"- {ac}" for ac in story.get("acceptanceCriteria", []))}
        T-shirt Size: {story.get("tshirt_size")}
        Priority: {story.get("priority")}
        Confidence Score: {story.get("confidence")}

        User feedback:
        "{feedback}"

        Based on this feedback, **revise the user story and acceptance criteria, strictly making only the changes requested in the user feedback.**
        **Do NOT modify any part (User Story ID, Title, Role, Story, Acceptance Criteria, T-shirt Size, Priority, Confidence Score) that is NOT explicitly addressed by the user's feedback.**

        Respond with raw JSON in the format:
        {{
            "usid": "<updated usid>",
            "title": "<updated title>",
            "role": "<updated role>",
            "story": "<updated user story>",
            "acceptanceCriteria": ["<updated criteria 1>", "<updated criteria 2>", ...],
            "tshirt_size": "<updated size>",
            "priority": "<updated priority>"
            "confidence": <updated confidence score between 0.0 and 1.0>
        }}

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object.
        """.strip()

        llm_response = self.llm_caller(prompt)

        try:
            updated = extract_clean_json(llm_response)
        except Exception as e:
            logger.error(f"Failed to parse LLM response: {e}")
            updated = {}

        return {"updated_story": updated or story}
