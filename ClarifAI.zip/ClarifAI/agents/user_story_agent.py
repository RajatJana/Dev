from typing import List, Dict, Callable
import json
import logging

from tools.prompt_utils import extract_clean_json

class UserStoryAgent:
    def __init__(self, llm_caller: Callable[[str], str]):
        self.llm_caller = llm_caller

    def run(self, inputs: Dict) -> Dict:
        validated = inputs["validated_requirements"]

        # Step 1: Filter functional and validated
        functional_reqs = [
            r for r in validated
            if r.get("requirement_type") == "Functional"
            and r.get("validation", {}).get("llm_check_passed") is True
        ]

        if not functional_reqs:
            return {"user_stories": []}

        # Step 2: Build prompt
        formatted = "\n".join([
            f'{r["requirement_id"]}: {r["requirement_text"]}' for r in functional_reqs
        ])
        #v1
        # prompt = f"""
        # You are a product owner.

        # For each of the following requirements, generate:
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story

        # Respond with raw JSON in the format:
        # [
        # {{
        #     "requirement_id": "REQ-001",
        #     "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
        #     "acceptance_criteria": [
        #     "User receives OTP after entering username.",
        #     "OTP must expire after 5 minutes.",
        #     "User cannot proceed without valid OTP."
        #     ],
        #     "confidence_score": 0.92,
        #     "tshirt_size": "M"
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()
        

        #v2
        # prompt = f"""
        # You are a product owner.

        # For each requirement, generate ONE OR MORE user stories (some requirements may result in multiple user stories).

        # For each user story, provide:

        # - title - short description
        # - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
        # - 2–4 clear acceptance criteria
        # - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
        # - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story
        # - priority - High/Medium/Low
        # - status - Draft/In Progress/Done
        # - Always start 1st user story id from US-001

        # Respond with raw JSON in the format (example):
        # [
        # {{
        # "requirement_id": "REQ-001",
        # "user_stories": [
        # {{
        # "id": "US-001"
        # "title": "Login validation"
        # "story": "As a user, I want to log in with OTP so that I can access my account securely.",
        # "acceptance_criteria": [
        # "User receives OTP after entering username.",
        # "OTP must expire after 5 minutes.",
        # "User cannot proceed without valid OTP."
        # ],
        # "priority": "High",
        # "tshirt_size": "M",
        # "confidence_score": 0.92
        # }},
        # ...
        # ]
        # }},
        # ...
        # ]

        # IMPORTANT:
        # - Do NOT use Markdown or triple backticks.
        # - Do NOT add explanations.
        # - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        # Requirements:
        # {formatted}
        # """.strip()

        #v3
        prompt = f"""
        You are a product owner.
        
        For each requirement, generate ONE OR MORE user stories (some requirements may result in multiple user stories).
        For the 1st Requirement generate atleast 3 user stories.

        For each user story, provide:
         - user_story_id (Always start 1st user story id from US-001)
         - title - short description
         - A user story in the format: "As a <role>, I want to <action>, so that <benefit>"
         - 3–4 clear acceptance criteria
         - A confidence score between 0.0 and 1.0 based on how confident you are that the requirement was converted correctly
         - A T-shirt size estimate (XS, S, M, L, XL) representing the relative effort or complexity to implement the user story
         - priority - High/Medium/Low


        Respond with raw JSON in the format:
        [
        {{
            "requirement_id": "REQ-001",
            "user_story_id": "US-001",
            "title": "User Authentication via OTP"
            "user_story": "As a user, I want to log in with OTP so that I can access my account securely.",
            "acceptance_criteria": [
            "User receives OTP after entering username.",
            "OTP must expire after 5 minutes.",
            "User cannot proceed without valid OTP."
            ],
            "confidence_score": 0.92,
            "tshirt_size": "M",
            "priority": "High"
        }},
        ...
        ]

        IMPORTANT:
        - Do NOT use Markdown or triple backticks.
        - Do NOT add explanations.
        - Respond only with a raw JSON object (no markdown, no ```json fences, no explanation).

        Requirements:
        {formatted}
        """.strip()
        llm_response = self.llm_caller(prompt)

        try:
            # parsed = json.loads(llm_response)
            parsed = extract_clean_json(llm_response)
        except Exception as e:
            logging.error(f"Failed to parse LLM response: {e}, raw: {llm_response[:500]}")
            parsed = []

        return {"user_stories": parsed}
