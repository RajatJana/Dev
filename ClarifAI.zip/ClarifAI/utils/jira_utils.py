import requests
from requests.auth import HTTPBasicAuth
import json

JIRA_URL = "https://.atlassian.net"
API_ENDPOINT = f"{JIRA_URL}/rest/api/2/issue/bulk"
EMAIL = "@outlook.com"
API_TOKEN =""
PROJECT_KEY = "TESTING"

def post_user_stories_to_jira(user_stories):
    issues_to_create = []
    for story in user_stories:
        issues_to_create.append({
            "fields": {
                "project": {"key": PROJECT_KEY},
                "summary": story["user_story"],
                "description": "\n".join(story.get("acceptance_criteria", [])),
                "issuetype": {"name": "Task"}
            }
        })

    payload = {"issueUpdates": issues_to_create}
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        API_ENDPOINT,
        headers=headers,
        auth=HTTPBasicAuth(EMAIL, API_TOKEN),
        data=json.dumps(payload)
    )

    if response.status_code == 201:
        print("Bulk issues created successfully!")
        return response.json()
    else:
        print(f"Failed with status code {response.status_code}")
        print(response.text)
        return None
    
###################################################################################################
def post_test_cases_to_jira(test_cases):
    issues_to_create = []
    for tc in test_cases:
        description = (
            f"*Precondition*: {tc.get('precondition', '')}\n"
            f"*Steps*:\n" +
            "\n".join([f"- {step}" for step in tc.get('steps', [])]) +
            f"\n*Expected Result*: {tc.get('expected_result', '')}\n"
            f"*Priority*: {tc.get('priority', '')}\n"
            f"*Tags*: {', '.join(tc.get('tags', []))}"
        )
        issues_to_create.append({
            "fields": {
                "project": {"key": PROJECT_KEY},
                "summary": tc.get("title", tc.get("test_id", "Test Case")),
                "description": description,
                "issuetype": {"name": "Task"}, 
                "labels": tc.get("tags", []),
                "priority": {"name": tc.get("priority", "Medium")},
            }
        })

    payload = {"issueUpdates": issues_to_create}
    headers = {"Content-Type": "application/json"}

    response = requests.post(
        API_ENDPOINT,
        headers=headers,
        auth=HTTPBasicAuth(EMAIL, API_TOKEN),
        data=json.dumps(payload)
    )

    if response.status_code == 201:
        print("Bulk test cases created successfully!")
        return response.json()
    else:
        print(f"Failed with status code {response.status_code}")
        print(response.text)
        return None